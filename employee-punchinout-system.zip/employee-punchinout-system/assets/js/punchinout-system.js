jQuery(document).ready(function () {

    punchinout();

   function punchinout() {
       fetchServerTime();
       fetchStatusAndUpdateUI();
       setupButtonHandlers();
   }

    function fetchServerTime() {
        jQuery.ajax({
            url: eps_ajax.ajax_url,
            type: 'POST',
            data: { action: 'get_server_time' },
            success: function (response) {
                if (response?.server_time) {
                    let serverTime = moment.tz(response.server_time, "Asia/Kolkata");
                    clockRunner(serverTime);
                }
            }
        });
    }

    function clockRunner(initialTime) {
        function updateClock() {
            let time = initialTime.format('dddd, MMMM Do YYYY, h:mm:ss A');
            jQuery('#clock').html(time);
            initialTime.add(1, 'seconds');
            setTimeout(updateClock, 1000);
        }
        updateClock();
    }

    function fetchStatusAndUpdateUI() {
        jQuery.ajax({
            url: eps_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'eps_get_employee_status',
                _ajax_nonce: eps_ajax.nonce_action
            },
            success: function (res) {
                if (res?.data) {
                    updateButtonVisibility(res.data);
                    updateTimeDisplays(res.data);
                }
            }
        });
    }
    function updateButtonVisibility(status) {
        jQuery('#punchInBtn, #punchOutBtn, #lunchOutBtn, #lunchInBtn').hide();
    
        if (!status.punched_in || status.punched_out) {
            jQuery('#punchInBtn').show();
        } else {
            jQuery('#punchOutBtn').show();
    
            //  If lunch is already completed, hide both lunch buttons permanently for the day
            if (status.lunch_done) {
                jQuery('#lunchOutBtn, #lunchInBtn').hide();
            } else {
                if (!status.lunch_out) {
                    jQuery('#lunchOutBtn').show();
                } else {
                    jQuery('#lunchInBtn').show();
                }
            }
        }
    }
    
    

    function updateTimeDisplays(status) {
        if (status.total_work_time) {
            jQuery('#finalTotalWorkTime').text(status.total_work_time);
        }
        if (status.total_lunch_time) {
            jQuery('#finalTotalLunchTime').text(status.total_lunch_time);
        }
        // if (status.log_entries && !status.punched_out) {
        //     startLiveWorkCounter(status.log_entries);
        // } else {
        //     jQuery('#liveWorkTime').text('');
        // }
        
    }

    function setupButtonHandlers() {
        jQuery('#punchInBtn').click(() => performAction('punch_in'));
        jQuery('#punchOutBtn').click(() => performAction('punch_out'));
        jQuery('#lunchOutBtn').click(() => performAction('lunch_out'));
        jQuery('#lunchInBtn').click(() => performAction('lunch_in'));
        
        // To reset search filter 
        jQuery('#resetFilters').on('click', function () {
            // Clear all filter inputs
            jQuery('#filterYear').val('');
            jQuery('#filterMonth').val('');
            jQuery('#filterEmployee').val('');
            jQuery('#filterStartDate').val('');
            jQuery('#filterEndDate').val('');
             // Clear global search text too
        jQuery('.dataTables_filter input').val('');
            
            // Redraw all DataTables
            jQuery('#leaveTable').DataTable().draw();
            jQuery('#attendanceViewTable').DataTable().draw();
            jQuery('#adminViewleaveTable').DataTable().draw();
            jQuery('#employeeListTable').DataTable().draw();
        });
    }

    function performAction(actionType) {
        console.log(`Action type in performaction: ${actionType}`);
        jQuery.ajax({
            url: eps_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'eps_perform_action',
                entry_type: actionType,
                _ajax_nonce: eps_ajax.nonce_perform_action
            },
            success: function (res) {
                if (res?.data?.error) {
                    alert(res.data.error);
                } else {
                    const message = res?.data?.message || 'Action completed.';
                    const entryType = actionType;
                    logEntry(message, entryType, res.data.total_work_time, res.data.total_lunch_time);
                    fetchStatusAndUpdateUI();
                }
            }
        });
    }

    function logEntry(entry, entry_type, workTime = '00:00:00', lunchTime = '00:00:00', serverTime = null) {
        const now = serverTime
            ? moment.tz(serverTime, "Asia/Kolkata").format('YYYY-MM-DD hh:mm:ss A')
            : moment().tz("Asia/Kolkata").format('YYYY-MM-DD hh:mm:ss A');

        let formatted = `
            <div class="eps-log-entry">
                <strong>Action:</strong> ${entry}<br>
                <strong>Time:</strong> ${now}<br>
                ${entry_type === 'punch_out' ? `<strong>Net Work Time:</strong> ${workTime}<br><strong>Lunch Time:</strong> ${lunchTime}` : ''}
            </div><hr>`;

        jQuery('#log').prepend(formatted);
        jQuery('#log').find('.eps-log-entry:first').css('background-color', '#e0f7fa');
        setTimeout(() => {
            jQuery('#log').find('.eps-log-entry:first').css('background-color', '#f9f9f9');
        }, 1000);
    }

    

});
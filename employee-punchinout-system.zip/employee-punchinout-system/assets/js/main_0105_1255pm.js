jQuery(document).ready(function () {
   // console.log(`Ajax url: ${eps_ajax.ajax_url}`);
   let table;

   init();

   function init() {
       fetchServerTime();
       fetchStatusAndUpdateUI();
       setupButtonHandlers();
       generateYearOptions('#filterYear');
       generateMonthOptions('#filterMonth');
       addDateRangeInputs(); //for date filter
       initCustomDataTable('#leaveTable');
       initCustomDataTable('#attendanceViewTable');
       initCustomDataTable('#adminViewleaveTable');
       initCustomDataTable('#leavesSummaryTable');
       initCustomDataTable('#myAttendanceTable');
       initEmployeeListTable('#employeeListTable');
   }

    function fetchServerTime() {
        jQuery.ajax({
            url: eps_ajax.ajax_url,
            type: 'POST',
            data: { action: 'get_server_time' },
            success: function (response) {
                if (response?.server_time) {
                    let serverTime = moment.tz(response.server_time, "Asia/Kolkata");
                    clockRunner(serverTime);
                }
            }
        });
    }

    function clockRunner(initialTime) {
        function updateClock() {
            let time = initialTime.format('dddd, MMMM Do YYYY, h:mm:ss A');
            jQuery('#clock').html(time);
            initialTime.add(1, 'seconds');
            setTimeout(updateClock, 1000);
        }
        updateClock();
    }

    function fetchStatusAndUpdateUI() {
        jQuery.ajax({
            url: eps_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'eps_get_employee_status',
                _ajax_nonce: eps_ajax.nonce_action
            },
            success: function (res) {
                if (res?.data) {
                    updateButtonVisibility(res.data);
                    updateTimeDisplays(res.data);
                }
            }
        });
    }
    function updateButtonVisibility(status) {
        jQuery('#punchInBtn, #punchOutBtn, #lunchOutBtn, #lunchInBtn').hide();
    
        if (!status.punched_in || status.punched_out) {
            jQuery('#punchInBtn').show();
        } else {
            jQuery('#punchOutBtn').show();
    
            //  If lunch is already completed, hide both lunch buttons permanently for the day
            if (status.lunch_done) {
                jQuery('#lunchOutBtn, #lunchInBtn').hide();
            } else {
                if (!status.lunch_out) {
                    jQuery('#lunchOutBtn').show();
                } else {
                    jQuery('#lunchInBtn').show();
                }
            }
        }
    }
    
    

    function updateTimeDisplays(status) {
        if (status.total_work_time) {
            jQuery('#finalTotalWorkTime').text(status.total_work_time);
        }
        if (status.total_lunch_time) {
            jQuery('#finalTotalLunchTime').text(status.total_lunch_time);
        }
    }

    function setupButtonHandlers() {
        jQuery('#punchInBtn').click(() => performAction('punch_in'));
        jQuery('#punchOutBtn').click(() => performAction('punch_out'));
        jQuery('#lunchOutBtn').click(() => performAction('lunch_out'));
        jQuery('#lunchInBtn').click(() => performAction('lunch_in'));
        
        // To reset search filter 
        jQuery('#resetFilters').on('click', function () {
            // Clear all filter inputs
            jQuery('#filterYear').val('');
            jQuery('#filterMonth').val('');
            jQuery('#filterEmployee').val('');
            jQuery('#filterStartDate').val('');
            jQuery('#filterEndDate').val('');
             // Clear global search text too
        jQuery('.dataTables_filter input').val('');
            
            // Redraw all DataTables
            jQuery('#leaveTable').DataTable().draw();
            jQuery('#attendanceViewTable').DataTable().draw();
            jQuery('#adminViewleaveTable').DataTable().draw();
            jQuery('#employeeListTable').DataTable().draw();
        });
    }

    function performAction(actionType) {
        console.log(`Action type in performaction: ${actionType}`);
        jQuery.ajax({
            url: eps_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'eps_perform_action',
                entry_type: actionType,
                _ajax_nonce: eps_ajax.nonce_perform_action
            },
            success: function (res) {
                if (res?.data?.error) {
                    alert(res.data.error);
                } else {
                    const message = res?.data?.message || 'Action completed.';
                    const entryType = actionType;
                    logEntry(message, entryType, res.data.total_work_time, res.data.total_lunch_time);
                    fetchStatusAndUpdateUI();
                }
            }
        });
    }

    function logEntry(entry, entry_type, workTime = '00:00:00', lunchTime = '00:00:00', serverTime = null) {
        const now = serverTime
            ? moment.tz(serverTime, "Asia/Kolkata").format('YYYY-MM-DD hh:mm:ss A')
            : moment().tz("Asia/Kolkata").format('YYYY-MM-DD hh:mm:ss A');

        let formatted = `
            <div class="eps-log-entry">
                <strong>Action:</strong> ${entry}<br>
                <strong>Time:</strong> ${now}<br>
                ${entry_type === 'punch_out' ? `<strong>Net Work Time:</strong> ${workTime}<br><strong>Lunch Time:</strong> ${lunchTime}` : ''}
            </div><hr>`;

        jQuery('#log').prepend(formatted);
        jQuery('#log').find('.eps-log-entry:first').css('background-color', '#e0f7fa');
        setTimeout(() => {
            jQuery('#log').find('.eps-log-entry:first').css('background-color', '#f9f9f9');
        }, 1000);
    }

     /********* * Dynamic Leave Type Fields Toggle **********/
    
    jQuery('input[name="leave_type"]').on('change', function () {
        let type = jQuery(this).val();
        console.log("Leave type changed to:", type); // Add this
        // Hide all conditional sections first
        jQuery('.leave-fields').hide();

        // Show the relevant fields based on selected leave type
        if (type === 'full_day') {
            jQuery('#full_day_fields').show();
        } else if (type === 'half_day') {
            jQuery('#half_day_fields').show();
        } else if (type === 'short_leave') {
            jQuery('#short_leave_fields').show();
        }
    });

    // Trigger change on page load to display correct section if already selected
    jQuery('input[name="leave_type"]:checked').trigger('change');

    //Apply for Leave functionality for employee
   
    jQuery('#leaveApplicationForm').off('submit').on('submit', function (e) {
        e.preventDefault();
        const leaveType = jQuery('input[name="leave_type"]:checked').val();
        const subject = jQuery('#subject').val();
        // const from_date = jQuery('#from_date').val();
        // const to_date = jQuery('#to_date').val();
        const reason = jQuery('#reason').val();

         // Gather dates based on leave type
         let from_date = '', to_date = '', half_day_type = '', half_day_date = '', short_leave_slot = '', short_leave_date = '';
         if (leaveType === 'full_day') {
            from_date = jQuery('#from_date').val();
            to_date = jQuery('#to_date').val();
        } else if (leaveType === 'half_day') {
            half_day_type = jQuery('input[name="half_day_type"]:checked').val();
            half_day_date = jQuery('#half_day_date').val();
        } else if (leaveType === 'short_leave') {
            short_leave_slot = jQuery('input[name="short_leave_slot"]:checked').val();
            short_leave_date = jQuery('#short_leave_date').val();
        }

       // console.log('Submitting leave application:', { subject, from_date, to_date, reason });
        console.log('AJAX URL:', eps_ajax.ajax_url); // Should log the correct URL

        jQuery.ajax({
            url: eps_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'eps_apply_leave',
                nonce: eps_ajax.nonce,
                leave_type: leaveType,
                subject: subject,
                reason: reason,
                from_date: from_date,
                to_date: to_date,
                half_day_type: half_day_type,
                half_day_date: half_day_date,
                short_leave_slot: short_leave_slot,
                short_leave_date: short_leave_date
            },
            success: function(response) {
                if (response.success) {
                    jQuery('#leaveApplicationMessage').html('<p>' + response.data.message + '</p>');
                    jQuery('#leaveApplicationForm')[0].reset();
                    jQuery('.leave-fields').hide();
                } else {
                    jQuery('#leaveApplicationMessage').html('<p>Error: ' + (response.data.message || 'Unknown error') + '</p>');
                }
            },
            error: function (xhr, status, error) {
                console.log('AJAX Error:', status, error);
                jQuery('#leaveApplicationMessage').html('<p>An error occurred. Please try again.</p>');
            }
        });
    });

    jQuery(document).on('click', '.edit-leave-btn', function () {
        var $row = jQuery(this).closest('tr');
    
        // Enable only subject, reason, and leave_type
        $row.find('.subject, .reason').prop('readonly', false);
        $row.find('.leave-type').prop('disabled', false);
    
        // Disable everything else initially
        $row.find('.from-date, .to-date').prop('readonly', true);
        $row.find('.half-day-type, .short-leave-time').prop('disabled', true);
    
        // Enable fields based on selected leave type
        var selectedType = $row.find('.leave-type').val();
        handleLeaveTypeFields($row, selectedType);
    
        // Setup change listener again (optional safety)
        $row.find('.leave-type').off('change').on('change', function () {
            var selectedType = jQuery(this).val();
            handleLeaveTypeFields($row, selectedType);
        });
    
        // Change Edit button to Update mode
        $row.find('.edit-leave-btn')
            .text('Update Leave')
            .removeClass('edit-leave-btn')
            .addClass('update-leave-btn');
       
    });

// Handle View Log button click
jQuery(document).on('click', '.view-log-btn', function () {
    const leaveId = jQuery(this).data('leave-id'); // Get the leave ID from the data attribute

    // Debug: Check if employee_name is correctly set
    console.log('Employee Name:', eps_ajax.employee_name);

    // Construct the log file URL using the employee name and leave ID
    const logFilePath = eps_ajax.plugin_url + 'leaveslogs/' + eps_ajax.employee_name + '_leaveid_' + leaveId + '_leavelog.txt';

    // Open a new tab with the log file URL
    window.open(logFilePath, '_blank');
});
    function handleLeaveTypeFields($row, leaveType) {
        // Reset all optional fields to disabled/read-only
        $row.find('.from-date, .to-date').prop('readonly', true);
        $row.find('.half-day-type, .short-leave-time').prop('disabled', true);
    
        if (leaveType === 'full_day') {
            $row.find('.from-date, .to-date').prop('readonly', false);
        } else if (leaveType === 'half_day') {
            $row.find('.from-date').prop('readonly', false);
            $row.find('.half-day-type').prop('disabled', false);
        } else if (leaveType === 'short_leave') {
            $row.find('.from-date').prop('readonly', false);
            $row.find('.short-leave-time').prop('disabled', false);
        }
    }
    
    // Handle Update button click
    jQuery(document).on('click', '.update-leave-btn', function() {
        const leaveId = jQuery(this).data('leave-id');
        
        const subject = jQuery(`#leave-row-${leaveId} .subject`).val();
        const fromDate = jQuery(`#leave-row-${leaveId} .from-date`).val();
        const toDate = jQuery(`#leave-row-${leaveId} .to-date`).val();
        const reason = jQuery(`#leave-row-${leaveId} .reason`).val();
        const leavetype = jQuery(`#leave-row-${leaveId} .leave-type`).val();
        const halfdaytype = jQuery(`#leave-row-${leaveId} .half-day-type`).val();
        const shortleavetime = jQuery(`#leave-row-${leaveId} .short-leave-time`).val();
        const date_applied = jQuery(`#leave-row-${leaveId} .date-applied`).val();
    
        // Only send fields that have been changed
        let updateData = {};
        if (subject) updateData.subject = subject;
        if (fromDate) updateData.from_date = fromDate;
        if (toDate) updateData.to_date = toDate;
        if (reason) updateData.reason = reason;
        if (leavetype) updateData.leave_type = leavetype;
        if (halfdaytype) updateData.half_day_type = halfdaytype;
        if (shortleavetime) updateData.short_leave_time = shortleavetime;
        if (date_applied) updateData.date_applied = date_applied;
    
        jQuery.ajax({
            url: eps_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'eps_update_leave',
                leave_id: leaveId,
                update_data: updateData,  // Send only changed data
                nonce: eps_ajax.nonce_upleave
            },
            success: function(response) {
                if (response.success) {
                    const $row = jQuery(`#leave-row-${leaveId}`);
            
                    // Reset or update all inputs
                    $row.find('.subject').val(response.data.subject).prop('readonly', true);
                    $row.find('.from-date').val(response.data.from_date).prop('readonly', true);
                    $row.find('.to-date').val(response.data.to_date).prop('readonly', true);
                    $row.find('.reason').val(response.data.reason).prop('readonly', true);
                    $row.find('.leave-type').val(response.data.leave_type).prop('disabled', true);
            
                    // Clear irrelevant optional fields
                    if (response.data.leave_type === 'full_day') {
                        $row.find('.half-day-type').val('').prop('disabled', true);
                        $row.find('.short-leave-time').val('').prop('disabled', true);
                    } else if (response.data.leave_type === 'half_day') {
                        $row.find('.half-day-type').val(response.data.half_day_type).prop('disabled', false);
                        $row.find('.short-leave-time').val('').prop('disabled', true);
                        $row.find('.to-date').val('').prop('readonly', true);
                    } else if (response.data.leave_type === 'short_leave') {
                        $row.find('.short-leave-time').val(response.data.short_leave_time).prop('disabled', false);
                        $row.find('.half-day-type').val('').prop('disabled', true);
                        $row.find('.to-date').val('').prop('readonly', true);
                    }
            
                    $row.find('.date-applied').val(response.data.date_applied).prop('readonly', true);
            
                    // Revert button back to Edit
                    $row.find(`.update-leave-btn`)
                        .text('Edit Leave')
                        .removeClass('update-leave-btn')
                        .addClass('edit-leave-btn');
            
                    // Show confirmation message
                    jQuery('#leaveApplicationMessage').html('<p>' + response.data.message + '</p>');
                } else {
                    jQuery('#leaveApplicationMessage').html('<p>Error: ' + response.data.message + '</p>');
                }
            },
            error: function(xhr, status, errorThrown) {
                console.log('AJAX Error:', status, errorThrown);
                console.log('Response Text:', xhr.responseText);
            }
        });
    });
    
    jQuery('.delete-leave').on('click', function() {
        let leave_id = jQuery(this).data('id');
        if (confirm('Are you sure you want to delete this leave application?')) {
            jQuery.ajax({
                url: eps_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'eps_delete_leave_application',
                    leave_id: leave_id
                },
                success: function(response) {
                    if (response.success) {
                        location.reload();
                    } else {
                        jQuery('#leaveApplicationMessage').html('<p>' + response.data.message + '</p>');
                    }
                }
            });
        }
    });


        
 //Update Leave status By Admin/Super Admin Or HR
    // Handle Update button click
    jQuery(document).on('click', '.update-leave-status-btn', function() {
        const leaveId = jQuery(this).data('leave-id');
        
        // Get values
        const status = jQuery(`#leave-row-${leaveId} .status-select`).val();
        
        // Make AJAX request to update status in the database
        jQuery.ajax({
            url: eps_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'eps_update_leave_status',
                leave_id: leaveId,
                status: status,  // Pass selected status
                nonce: eps_ajax.nonce_update_leave // Ensure nonce is passed
            },
            success: function(response) {
                if (response.success) {
                    // Update UI to reflect the change
                    jQuery(`#leave-row-${leaveId} .status-select`).replaceWith(`<input type="text" class="status" value="${status}" readonly>`);
                    jQuery(`#leave-row-${leaveId} .update-leave-status-btn`)
                        .text('Updated')
                        .addClass('updated-leave-status-btn')
                        .removeClass('update-leave-status-btn');
                    
                    jQuery('#leaveStatusMessage').html('<p>Leave status updated successfully.</p>');
                } else {
                    jQuery('#leaveStatusMessage').html('<p>Error updating status. Please try again.</p>');
                }
            },
            error: function(error) {
                console.log('AJAX Error:', error);
            }
        });
    });


    document.addEventListener('DOMContentLoaded', function() {
        const passwordOptionInputs = document.querySelectorAll('input[name="employee_password_option"]');
        const customPasswordRow = document.getElementById('custom-password-row');

        passwordOptionInputs.forEach(input => {
            input.addEventListener('change', function() {
                if (this.value === 'custom') {
                    customPasswordRow.style.display = '';
                } else {
                    customPasswordRow.style.display = 'none';
                }
            });
        });
    });


// View Employee details in popup
jQuery(document).on('click', '.view-details-btn', function() {
    var row = jQuery(this).closest('tr');
    var empId = row.find('.emp-id').val();
    var name = row.find('.emp-name').val();
    var email = row.find('.emp-email').val();
    var department = row.find('.emp-depart').val();
    var designation = row.find('.emp-desig').val();
    var jobType = row.find('.emp-job_type').val();
    var createdAt = row.find('.emp-add-date').val();

    var detailsHtml = `
        <p><strong>Employee ID:</strong> ${empId}</p>
        <p><strong>Name:</strong> ${name}</p>
        <p><strong>Email:</strong> ${email}</p>
        <p><strong>Department:</strong> ${department}</p>
        <p><strong>Designation:</strong> ${designation}</p>
        <p><strong>Job Type:</strong> ${jobType}</p>
        <p><strong>Created At:</strong> ${createdAt}</p>
    `;

    jQuery('#modalDetails').html(detailsHtml);
    jQuery('#employeeDetailsModal').fadeIn();
});

// Close modal
jQuery(document).on('click', '.close-modal', function() {
    jQuery('#employeeDetailsModal').fadeOut();
});

function generateYearOptions(selector) {
    const currentYear = new Date().getFullYear();
    for (let y = currentYear; y >= 2000; y--) {
        jQuery(selector).append(`<option value="${y}">${y}</option>`);
    }
}

function generateMonthOptions(selector) {
    const months = [
        'January', 'February', 'March', 'April', 'May', 'June',
        'July', 'August', 'September', 'October', 'November', 'December'
    ];
    months.forEach((month, index) => {
        const monthNumber = ('0' + (index + 1)).slice(-2); // 01, 02, etc.
        jQuery(selector).append(`<option value="${monthNumber}">${month}</option>`);
    });
}

function addDateRangeInputs() {
    const filterContainer = `
        <label for="filterStartDate">Start Date:</label>
        <input type="date" id="filterStartDate">
        <label for="filterEndDate">End Date:</label>
        <input type="date" id="filterEndDate">
    `;
    jQuery('#filterMonth').after(filterContainer);
}
function initCustomDataTable(tableSelector) {
    const customTable = jQuery(tableSelector).DataTable({
        dom: 'Bfrtip',
        buttons: ['copy', 'csv', 'excel', 'pdf', 'print'],
        scrollX: true,
        scrollY: '400px',
        scrollCollapse: true,
        paging: true,
        responsive: false,
        order: [[1, 'desc']],
        language: {
            search: "",
            searchPlaceholder: "Search by name, ID, or leave 2025-01"
        },
    });

    // Redraw table when year/month filter changes
    jQuery('#filterYear, #filterMonth, #filterEmployee, #filterStartDate, #filterEndDate').on('change keyup', function () {
        customTable.draw();
    });
}

function initEmployeeListTable(tableSelector) {
    jQuery(tableSelector).DataTable({
        dom: 'Bfrtip',
        buttons: ['copy', 'csv', 'excel', 'pdf', 'print'],
        scrollX: true,
        scrollY: '400px',
        scrollCollapse: true,
        paging: true,
        responsive: false,
        language: {
            search: "",
            searchPlaceholder: "Search by Employee Name or ID"
        }
    });
    jQuery('#filterYear, #filterMonth, #filterEmployee, #filterStartDate, #filterEndDate').on('change keyup', function () {
        jQuery(tableSelector).DataTable().draw();
    });
}

// Global Custom Filter for Year and Month
// Global Custom Filter for Year and Month
jQuery.fn.dataTable.ext.search.push(function (settings, data, dataIndex) {
    const tableId = settings.nTable.getAttribute('id');
    const selectedYear = jQuery('#filterYear').val();
    const selectedMonth = jQuery('#filterMonth').val();
    const employeeFilter = jQuery('#filterEmployee').val() ? jQuery('#filterEmployee').val().toLowerCase() : '';
    const startDateFilter = jQuery('#filterStartDate').val();
    const endDateFilter = jQuery('#filterEndDate').val();
    let rowDate = '';
    let employeeId = '';
    let employeeName = '';

    const $row = jQuery(settings.aoData[dataIndex].nTr);

    if (tableId === 'leaveTable' || tableId === 'adminViewleaveTable') {
        rowDate = $row.find('.from-date').val() || $row.find('.from-date').text().trim();
        employeeName = ($row.find('.employee-name').val() || $row.find('.employee-name').text()).trim().toLowerCase();
        employeeId = ($row.find('.employee-id').val() || $row.find('.employee-id').text()).trim().toLowerCase();
    } else if (tableId === 'attendanceViewTable' || tableId === 'myAttendanceTable') {
        rowDate = $row.find('.log-date').val() || $row.find('.log-date').text().trim();
        employeeName = ($row.find('.employee-name').val() || $row.find('.employee-name').text()).trim().toLowerCase();
        employeeId = ($row.find('.employee-id').val() || $row.find('.employee-id').text()).trim().toLowerCase();
    } else if (tableId === 'employeeListTable') {
        employeeName = ($row.find('.employee-name').val() || $row.find('.employee-name').text()).trim().toLowerCase();
        employeeId = ($row.find('.employee-id').val() || $row.find('.employee-id').text()).trim().toLowerCase();
    } else {
        return true;
    }

    // Fix invalid "0000-00-00" dates
    if (rowDate === "0000-00-00") {
        rowDate = "";
    }

    // Year and Month filtering
    if (rowDate) {
        const date = new Date(rowDate);
        if (!isNaN(date)) {
            const yearMatch = selectedYear === '' || date.getFullYear() == selectedYear;
            const monthMatch = selectedMonth === '' || (('0' + (date.getMonth() + 1)).slice(-2)) == selectedMonth;
            if (!(yearMatch && monthMatch)) return false;
        }
    }
    // --- Date Range Filtering ---
    if (startDateFilter || endDateFilter) {
        if (!rowDate) return false;

        const rowTimestamp = new Date(rowDate).getTime();
        if (startDateFilter) {
            const startTimestamp = new Date(startDateFilter).getTime();
            if (rowTimestamp < startTimestamp) return false;
        }
        if (endDateFilter) {
            const endTimestamp = new Date(endDateFilter).getTime();
            if (rowTimestamp > endTimestamp) return false;
        }
    }

    // Employee Name / ID filtering
    if (employeeFilter) {
        const matchName = employeeName.includes(employeeFilter);
        const matchId = employeeId.includes(employeeFilter);
        return matchName || matchId;
    }

    return true;
});
jQuery('.edit-employee-multistep-btn').on('click', function() {
    let empId = jQuery(this).data('emp-id');
    let targetUrl = eps_ajax.profilePageUrl;
    window.location.href = targetUrl + "&empid=" + empId;
});

});



jQuery(document).ready(function () {
   // console.log(`Ajax url: ${eps_ajax.ajax_url}`);
   let table;

   init();

   function init() {
       generateYearOptions('#filterYear');
       generateMonthOptions('#filterMonth');
       addDateRangeInputs(); //for date filter
       initCustomDataTable('#leaveTable');
       initCustomDataTable('#attendanceViewTable');
       initCustomDataTable('#adminViewleaveTable');
       initCustomDataTable('#leavesSummaryTable');
       initCustomDataTable('#myAttendanceTable');
       initEmployeeListTable('#employeeListTable');
   } 

function generateYearOptions(selector) {
    const currentYear = new Date().getFullYear();
    for (let y = currentYear; y >= 2000; y--) {
        jQuery(selector).append(`<option value="${y}">${y}</option>`);
    }
}

function generateMonthOptions(selector) {
    const months = [
        'January', 'February', 'March', 'April', 'May', 'June',
        'July', 'August', 'September', 'October', 'November', 'December'
    ];
    months.forEach((month, index) => {
        const monthNumber = ('0' + (index + 1)).slice(-2); // 01, 02, etc.
        jQuery(selector).append(`<option value="${monthNumber}">${month}</option>`);
    });
}

function addDateRangeInputs() {
    const filterContainer = `
        <label for="filterStartDate">Start Date:</label>
        <input type="date" id="filterStartDate">
        <label for="filterEndDate">End Date:</label>
        <input type="date" id="filterEndDate">
    `;
    jQuery('#filterMonth').after(filterContainer);
}
function initCustomDataTable(tableSelector) {
    const customTable = jQuery(tableSelector).DataTable({
        dom: 'Bfrtip',
        buttons: ['copy', 'csv', 'excel', 'pdf', 'print'],
        scrollX: true,
        scrollY: '400px',
        scrollCollapse: true,
        paging: true,
        responsive: false,
        order: [[1, 'desc']],
        language: {
            search: "",
            searchPlaceholder: "Search by name, ID, or leave 2025-01"
        },
    });

    // Redraw table when year/month filter changes
    jQuery('#filterYear, #filterMonth, #filterEmployee, #filterStartDate, #filterEndDate').on('change keyup', function () {
        customTable.draw();
    });
}

function initEmployeeListTable(tableSelector) {
    jQuery(tableSelector).DataTable({
        dom: 'Bfrtip',
        buttons: ['copy', 'csv', 'excel', 'pdf', 'print'],
        scrollX: true,
        scrollY: '400px',
        scrollCollapse: true,
        paging: true,
        responsive: false,
        language: {
            search: "",
            searchPlaceholder: "Search by Employee Name or ID"
        }
    });
    jQuery('#filterYear, #filterMonth, #filterEmployee, #filterStartDate, #filterEndDate').on('change keyup', function () {
        jQuery(tableSelector).DataTable().draw();
    });
}

// Global Custom Filter for Year and Month
// Global Custom Filter for Year and Month
jQuery.fn.dataTable.ext.search.push(function (settings, data, dataIndex) {
    const tableId = settings.nTable.getAttribute('id');
    const selectedYear = jQuery('#filterYear').val();
    const selectedMonth = jQuery('#filterMonth').val();
    const employeeFilter = jQuery('#filterEmployee').val() ? jQuery('#filterEmployee').val().toLowerCase() : '';
    const startDateFilter = jQuery('#filterStartDate').val();
    const endDateFilter = jQuery('#filterEndDate').val();
    let rowDate = '';
    let employeeId = '';
    let employeeName = '';

    const $row = jQuery(settings.aoData[dataIndex].nTr);

    if (tableId === 'leaveTable' || tableId === 'adminViewleaveTable') {
        rowDate = $row.find('.from-date').val() || $row.find('.from-date').text().trim();
        employeeName = ($row.find('.employee-name').val() || $row.find('.employee-name').text()).trim().toLowerCase();
        employeeId = ($row.find('.employee-id').val() || $row.find('.employee-id').text()).trim().toLowerCase();
    } else if (tableId === 'attendanceViewTable' || tableId === 'myAttendanceTable') {
        rowDate = $row.find('.log-date').val() || $row.find('.log-date').text().trim();
        employeeName = ($row.find('.employee-name').val() || $row.find('.employee-name').text()).trim().toLowerCase();
        employeeId = ($row.find('.employee-id').val() || $row.find('.employee-id').text()).trim().toLowerCase();
    } else if (tableId === 'employeeListTable') {
        employeeName = ($row.find('.employee-name').val() || $row.find('.employee-name').text()).trim().toLowerCase();
        employeeId = ($row.find('.employee-id').val() || $row.find('.employee-id').text()).trim().toLowerCase();
    } else {
        return true;
    }

    // Fix invalid "0000-00-00" dates
    if (rowDate === "0000-00-00") {
        rowDate = "";
    }

    // Year and Month filtering
    if (rowDate) {
        const date = new Date(rowDate);
        if (!isNaN(date)) {
            const yearMatch = selectedYear === '' || date.getFullYear() == selectedYear;
            const monthMatch = selectedMonth === '' || (('0' + (date.getMonth() + 1)).slice(-2)) == selectedMonth;
            if (!(yearMatch && monthMatch)) return false;
        }
    }
    // --- Date Range Filtering ---
    if (startDateFilter || endDateFilter) {
        if (!rowDate) return false;

        const rowTimestamp = new Date(rowDate).getTime();
        if (startDateFilter) {
            const startTimestamp = new Date(startDateFilter).getTime();
            if (rowTimestamp < startTimestamp) return false;
        }
        if (endDateFilter) {
            const endTimestamp = new Date(endDateFilter).getTime();
            if (rowTimestamp > endTimestamp) return false;
        }
    }

    // Employee Name / ID filtering
    if (employeeFilter) {
        const matchName = employeeName.includes(employeeFilter);
        const matchId = employeeId.includes(employeeFilter);
        return matchName || matchId;
    }

    return true;
});


});



jQuery(document).ready(function () {
 /********* * Dynamic Leave Type Fields Toggle **********/
    
 jQuery('input[name="leave_type"]').on('change', function () {
    let type = jQuery(this).val();
    console.log("Leave type changed to:", type); // Add this
    // Hide all conditional sections first
    jQuery('.leave-fields').hide();

    // Show the relevant fields based on selected leave type
    if (type === 'full_day') {
        jQuery('#full_day_fields').show();
    } else if (type === 'half_day') {
        jQuery('#half_day_fields').show();
    } else if (type === 'short_leave') {
        jQuery('#short_leave_fields').show();
    }
});

// Trigger change on page load to display correct section if already selected
jQuery('input[name="leave_type"]:checked').trigger('change');

//Apply for Leave functionality for employee

jQuery('#leaveApplicationForm').off('submit').on('submit', function (e) {
    e.preventDefault();
    const leaveType = jQuery('input[name="leave_type"]:checked').val();
    const subject = jQuery('#subject').val();
    // const from_date = jQuery('#from_date').val();
    // const to_date = jQuery('#to_date').val();
    const reason = jQuery('#reason').val();

     // Gather dates based on leave type
     let from_date = '', to_date = '', half_day_type = '', half_day_date = '', short_leave_slot = '', short_leave_date = '';
     if (leaveType === 'full_day') {
        from_date = jQuery('#from_date').val();
        to_date = jQuery('#to_date').val();
    } else if (leaveType === 'half_day') {
        half_day_type = jQuery('input[name="half_day_type"]:checked').val();
        half_day_date = jQuery('#half_day_date').val();
    } else if (leaveType === 'short_leave') {
        short_leave_slot = jQuery('input[name="short_leave_slot"]:checked').val();
        short_leave_date = jQuery('#short_leave_date').val();
    }

   // console.log('Submitting leave application:', { subject, from_date, to_date, reason });
    console.log('AJAX URL:', eps_ajax.ajax_url); // Should log the correct URL

    jQuery.ajax({
        url: eps_ajax.ajax_url,
        type: 'POST',
        data: {
            action: 'eps_apply_leave',
            nonce: eps_ajax.nonce,
            leave_type: leaveType,
            subject: subject,
            reason: reason,
            from_date: from_date,
            to_date: to_date,
            half_day_type: half_day_type,
            half_day_date: half_day_date,
            short_leave_slot: short_leave_slot,
            short_leave_date: short_leave_date
        },
        success: function(response) {
            if (response.success) {
                jQuery('#leaveApplicationMessage').html('<p>' + response.data.message + '</p>');
                jQuery('#leaveApplicationForm')[0].reset();
                jQuery('.leave-fields').hide();
            } else {
                jQuery('#leaveApplicationMessage').html('<p>Error: ' + (response.data.message || 'Unknown error') + '</p>');
            }
        },
        error: function (xhr, status, error) {
            console.log('AJAX Error:', status, error);
            jQuery('#leaveApplicationMessage').html('<p>An error occurred. Please try again.</p>');
        }
    });
});

jQuery(document).on('click', '.edit-leave-btn', function () {
    var $row = jQuery(this).closest('tr');

    // Enable only subject, reason, and leave_type
    $row.find('.subject, .reason').prop('readonly', false);
    $row.find('.leave-type').prop('disabled', false);

    // Disable everything else initially
    $row.find('.from-date, .to-date').prop('readonly', true);
    $row.find('.half-day-type, .short-leave-time').prop('disabled', true);

    // Enable fields based on selected leave type
    var selectedType = $row.find('.leave-type').val();
    handleLeaveTypeFields($row, selectedType);

    // Setup change listener again (optional safety)
    $row.find('.leave-type').off('change').on('change', function () {
        var selectedType = jQuery(this).val();
        handleLeaveTypeFields($row, selectedType);
    });

    // Change Edit button to Update mode
    $row.find('.edit-leave-btn')
        .text('Update Leave')
        .removeClass('edit-leave-btn')
        .addClass('update-leave-btn');
   
});

// Handle View Log button click
jQuery(document).on('click', '.view-log-btn', function () {
const leaveId = jQuery(this).data('leave-id'); // Get the leave ID from the data attribute

// Debug: Check if employee_name is correctly set
console.log('Employee Name:', eps_ajax.employee_name);

// Construct the log file URL using the employee name and leave ID
const logFilePath = eps_ajax.plugin_url + 'leaveslogs/' + eps_ajax.employee_name + '_leaveid_' + leaveId + '_leavelog.txt';

// Open a new tab with the log file URL
window.open(logFilePath, '_blank');
});
function handleLeaveTypeFields($row, leaveType) {
    // Reset all optional fields to disabled/read-only
    $row.find('.from-date, .to-date').prop('readonly', true);
    $row.find('.half-day-type, .short-leave-time').prop('disabled', true);

    if (leaveType === 'full_day') {
        $row.find('.from-date, .to-date').prop('readonly', false);
    } else if (leaveType === 'half_day') {
        $row.find('.from-date').prop('readonly', false);
        $row.find('.half-day-type').prop('disabled', false);
    } else if (leaveType === 'short_leave') {
        $row.find('.from-date').prop('readonly', false);
        $row.find('.short-leave-time').prop('disabled', false);
    }
}

// Handle Update button click
jQuery(document).on('click', '.update-leave-btn', function() {
    const leaveId = jQuery(this).data('leave-id');
    
    const subject = jQuery(`#leave-row-${leaveId} .subject`).val();
    const fromDate = jQuery(`#leave-row-${leaveId} .from-date`).val();
    const toDate = jQuery(`#leave-row-${leaveId} .to-date`).val();
    const reason = jQuery(`#leave-row-${leaveId} .reason`).val();
    const leavetype = jQuery(`#leave-row-${leaveId} .leave-type`).val();
    const halfdaytype = jQuery(`#leave-row-${leaveId} .half-day-type`).val();
    const shortleavetime = jQuery(`#leave-row-${leaveId} .short-leave-time`).val();
    const date_applied = jQuery(`#leave-row-${leaveId} .date-applied`).val();

    // Only send fields that have been changed
    let updateData = {};
    if (subject) updateData.subject = subject;
    if (fromDate) updateData.from_date = fromDate;
    if (toDate) updateData.to_date = toDate;
    if (reason) updateData.reason = reason;
    if (leavetype) updateData.leave_type = leavetype;
    if (halfdaytype) updateData.half_day_type = halfdaytype;
    if (shortleavetime) updateData.short_leave_time = shortleavetime;
    if (date_applied) updateData.date_applied = date_applied;

    jQuery.ajax({
        url: eps_ajax.ajax_url,
        type: 'POST',
        data: {
            action: 'eps_update_leave',
            leave_id: leaveId,
            update_data: updateData,  // Send only changed data
            nonce: eps_ajax.nonce_upleave
        },
        success: function(response) {
            if (response.success) {
                const $row = jQuery(`#leave-row-${leaveId}`);
        
                // Reset or update all inputs
                $row.find('.subject').val(response.data.subject).prop('readonly', true);
                $row.find('.from-date').val(response.data.from_date).prop('readonly', true);
                $row.find('.to-date').val(response.data.to_date).prop('readonly', true);
                $row.find('.reason').val(response.data.reason).prop('readonly', true);
                $row.find('.leave-type').val(response.data.leave_type).prop('disabled', true);
        
                // Clear irrelevant optional fields
                if (response.data.leave_type === 'full_day') {
                    $row.find('.half-day-type').val('').prop('disabled', true);
                    $row.find('.short-leave-time').val('').prop('disabled', true);
                } else if (response.data.leave_type === 'half_day') {
                    $row.find('.half-day-type').val(response.data.half_day_type).prop('disabled', false);
                    $row.find('.short-leave-time').val('').prop('disabled', true);
                    $row.find('.to-date').val('').prop('readonly', true);
                } else if (response.data.leave_type === 'short_leave') {
                    $row.find('.short-leave-time').val(response.data.short_leave_time).prop('disabled', false);
                    $row.find('.half-day-type').val('').prop('disabled', true);
                    $row.find('.to-date').val('').prop('readonly', true);
                }
        
                $row.find('.date-applied').val(response.data.date_applied).prop('readonly', true);
        
                // Revert button back to Edit
                $row.find(`.update-leave-btn`)
                    .text('Edit Leave')
                    .removeClass('update-leave-btn')
                    .addClass('edit-leave-btn');
        
                // Show confirmation message
                jQuery('#leaveApplicationMessage').html('<p>' + response.data.message + '</p>');
            } else {
                jQuery('#leaveApplicationMessage').html('<p>Error: ' + response.data.message + '</p>');
            }
        },
        error: function(xhr, status, errorThrown) {
            console.log('AJAX Error:', status, errorThrown);
            console.log('Response Text:', xhr.responseText);
        }
    });
});

jQuery('.delete-leave').on('click', function() {
    let leave_id = jQuery(this).data('id');
    if (confirm('Are you sure you want to delete this leave application?')) {
        jQuery.ajax({
            url: eps_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'eps_delete_leave_application',
                leave_id: leave_id
            },
            success: function(response) {
                if (response.success) {
                    location.reload();
                } else {
                    jQuery('#leaveApplicationMessage').html('<p>' + response.data.message + '</p>');
                }
            }
        });
    }
});

});
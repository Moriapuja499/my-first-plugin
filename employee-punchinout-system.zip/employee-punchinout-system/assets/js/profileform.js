jQuery(document).ready(function () {
    // Check if data exists in sessionStorage
    let personalInfoData = JSON.parse(sessionStorage.getItem('personalInfoData'));
    let professionalInfoData = JSON.parse(sessionStorage.getItem('professionalInfoData'));
    //let documentsInfoData = JSON.parse(sessionStorage.getItem('documentsInfoData'));
    let accountAccessData = JSON.parse(sessionStorage.getItem('accountAccessData'));

    // Fill form fields if data exists in sessionStorage
    if (personalInfoData) {
        jQuery('#fnfirst_name').val(personalInfoData.first_name);
        jQuery('#fnlast_name').val(personalInfoData.last_name);
        jQuery('#fnmobile').val(personalInfoData.mobile);
        jQuery('#fnemail').val(personalInfoData.email);
        jQuery('#fndob').val(personalInfoData.dob);
        jQuery('#fnmarital_status').val(personalInfoData.marital_status);
        jQuery('#fngender').val(personalInfoData.gender);
        jQuery('#fnnationality').val(personalInfoData.nationality);
        jQuery('#fnaddress').val(personalInfoData.address);
        jQuery('#fncity').val(personalInfoData.city);
        jQuery('#fnstate').val(personalInfoData.state);
        jQuery('#fnzipcode').val(personalInfoData.zipcode);
    }

    if (professionalInfoData) {
        jQuery('#fnemp_id').val(professionalInfoData.emp_id);
        jQuery('#fnuser_name').val(professionalInfoData.user_name);
        jQuery('#fnemp_type').val(professionalInfoData.emp_type);
        jQuery('#fnpemail').val(professionalInfoData.pemail);
        jQuery('#fnemp_department').val(professionalInfoData.emp_department);
        jQuery('#fnemp_designation').val(professionalInfoData.emp_designation);
        jQuery('#fnworking_days').val(professionalInfoData.working_days);
        jQuery('#fnjoining_date').val(professionalInfoData.joining_date);
        jQuery('#fnoffice_loc').val(professionalInfoData.office_loc);
    }

    // if (documentsInfoData) {
    //     // Check if the file names are stored and display them in the form fields
    //     if (documentsInfoData.appointment_letter) {
    //         //jQuery('#fnappointment_letter').text(documentsInfoData.appointment_letter);
    //         jQuery('#fnappointment_letter_display').text(documentsInfoData.appointment_letter);
    //     } else {
    //         //jQuery('#fnappointment_letter').text('No file uploaded');
    //         jQuery('#fnappointment_letter_display').text('No file uploaded');
            
    //     }

    //     if (documentsInfoData.salary_slips) {
    //         //jQuery('#fnsalary_slips').text(documentsInfoData.salary_slips);
    //         jQuery('#fnsalary_slips_display').text(documentsInfoData.salary_slips);
    //     } else {
    //         //jQuery('#fnsalary_slips').text('No file uploaded');
    //         jQuery('#fnsalary_slips_display').text('No file uploaded');
    //     }

    //     if (documentsInfoData.reliving_letter) {
    //         //jQuery('#fnreliving_letter').text(documentsInfoData.reliving_letter);
    //         jQuery('#fnreliving_letter_display').text(documentsInfoData.reliving_letter);
    //     } else {
    //         //jQuery('#fnreliving_letter').text('No file uploaded');
    //         jQuery('#fnreliving_letter_display').text('No file uploaded');
    //     }

    //     if (documentsInfoData.experience_letter) {
    //         //jQuery('#fnexperience_letter').text(documentsInfoData.experience_letter);
    //         jQuery('#fnexperience_letter_display').text(documentsInfoData.experience_letter);
    //     } else {
    //         //jQuery('#fnexperience_letter').text('No file uploaded');
    //         jQuery('#fnexperience_letter_display').text('No file uploaded');
    //     }
    // } else {
    //     console.error("No documents information found in sessionStorage.");
    // }

    if (accountAccessData) {
        jQuery('#fnaemail').val(accountAccessData.aemail);
        jQuery('#fnstack_id').val(accountAccessData.stack_id);
        jQuery('#fnskype_id').val(accountAccessData.skype_id);
        jQuery('#fngithub_id').val(accountAccessData.github_id);
    }

    // Handling the submit button for personal info form
    let personalInfoBtn = document.getElementById('personalInfoBtn');
    if (personalInfoBtn) {
        personalInfoBtn.addEventListener('click', function (event) {
            event.preventDefault();
            sessionStorage.setItem('personalInfoData', JSON.stringify({
                first_name: document.getElementById('first_name').value,
                last_name: document.getElementById('last_name').value,
                mobile: document.getElementById('mobile').value,
                email: document.getElementById('email').value,
                dob: document.getElementById('dob').value,
                marital_status: document.getElementById('marital_status').value,
                gender: document.getElementById('gender').value,
                nationality: document.getElementById('nationality').value,
                address: document.getElementById('address').value,
                city: document.getElementById('city').value,
                state: document.getElementById('state').value,
                zipcode: document.getElementById('zipcode').value
            }));
            window.location.href = 'admin.php?page=eps_professional_info';
        });
    } else {
        console.error("Error: #personalInfoBtn not found.");
    }

    // Handling the submit button for professional info form
    let professionalInfoBtn = document.getElementById('professionalInfoBtn');
    if (professionalInfoBtn) {
        professionalInfoBtn.addEventListener('click', function (event) {
            event.preventDefault(); // Prevent the default form submission
            sessionStorage.setItem('professionalInfoData', JSON.stringify({
                emp_id: document.getElementById('emp_id').value,
                user_name: document.getElementById('user_name').value,
                emp_type: document.getElementById('emp_type').value,
                pemail: document.getElementById('pemail').value,
                emp_department: document.getElementById('emp_department').value,
                emp_designation: document.getElementById('emp_designation').value,
                working_days: document.getElementById('working_days').value,
                joining_date: document.getElementById('joining_date').value,
                office_loc: document.getElementById('office_loc').value
            }));
            //window.location.href = 'admin.php?page=eps_documents';
            window.location.href = 'admin.php?page=eps_account_access';
            
        });
    } else {
        console.error("Error: #professionalInfoBtn not found.");
    }

    let accountAccessBtn = document.getElementById('accountAccessBtn');
    if (accountAccessBtn) {
        accountAccessBtn.addEventListener('click', function (event) {
            event.preventDefault(); // Prevent the default form submission
            sessionStorage.setItem('accountAccessData', JSON.stringify({
                aemail: document.getElementById('aemail').value,
                stack_id: document.getElementById('stack_id').value,
                skype_id: document.getElementById('skype_id').value,
                github_id: document.getElementById('github_id').value
            }));
            //window.location.href = 'admin.php?page=eps_documents';
            window.location.href = 'admin.php?page=eps_complete_form';
            
        });
    } else {
        console.error("Error: #professionalInfoBtn not found.");
    }
    // Handling the file uploads and storing file names in sessionStorage
    // let documentsInfoBtn = document.getElementById('documentsInfoBtn');
    // if (documentsInfoBtn) {
    //     documentsInfoBtn.addEventListener('click', function (event) {
    //         event.preventDefault(); // Prevent the default form submission

    //         // Collect file data
    //         let appointmentLetter = document.getElementById('appointment_letter').files[0] || null;
    //         let salarySlips = document.getElementById('salary_slips').files[0] || null;
    //         let relivingLetter = document.getElementById('reliving_letter').files[0] || null;
    //         let experienceLetter = document.getElementById('experience_letter').files[0] || null;

    //         // Create FormData to upload the files
    //         let formData = new FormData();
    //         if (appointmentLetter) formData.append('appointment_letter', appointmentLetter);
    //         if (salarySlips) formData.append('salary_slips', salarySlips);
    //         if (relivingLetter) formData.append('reliving_letter', relivingLetter);
    //         if (experienceLetter) formData.append('experience_letter', experienceLetter);

    //         // Send the files to the server via AJAX
    //         fetch('upload.php', {
    //             method: 'POST',
    //             body: formData
    //         })
    //         .then(response => response.json())
    //         .then(data => {
    //             if (data.success) {
    //                 // Store the file data in sessionStorage
    //                 sessionStorage.setItem('documentsInfoData', JSON.stringify({
    //                     appointment_letter: data.appointment_letter,
    //                     salary_slips: data.salary_slips,
    //                     reliving_letter: data.reliving_letter,
    //                     experience_letter: data.experience_letter
    //                 }));

    //                 // Redirect to the next page
    //                 window.location.href = 'admin.php?page=eps_account_access';
    //             } else {
    //                 alert('File upload failed: ' + data.message);
    //             }
    //         })
    //         .catch(error => {
    //             console.error('Error uploading files:', error);
    //         });
    //     });
    // } else {
    //     console.error("Error: #documentsInfoBtn not found.");
    // }

    // Final form submission to save all data
    jQuery('#finalSubmitsBtn').click(function (event) {
        event.preventDefault();

        // Optional: Disable the button to prevent multiple submissions
        jQuery(this).attr('disabled', true).val('Submitting...');

        // Collect all stored data from sessionStorage
        let personalInfo = JSON.parse(sessionStorage.getItem('personalInfoData'));
        let professionalInfo = JSON.parse(sessionStorage.getItem('professionalInfoData'));
        //let documentsInfo = JSON.parse(sessionStorage.getItem('documentsInfoData'));
        let accountAccessInfo = JSON.parse(sessionStorage.getItem('accountAccessData'));

        // Get the form data
        let formData = new FormData(document.getElementById('finalFormSubmits'));

        // Add other non-file data
        formData.append('action', 'save_employee_data');
        formData.append('personalInfo', JSON.stringify(personalInfo));
        formData.append('professionalInfo', JSON.stringify(professionalInfo));
        //formData.append('documentsInfo', JSON.stringify(documentsInfo));
        formData.append('accountAccessInfo', JSON.stringify(accountAccessInfo));

        // Send data to the backend via AJAX
        jQuery.ajax({
            url: eps_ajax.ajax_url,
            type: 'POST',
            data: formData,
            contentType: false, // Important for FormData
            processData: false, // Important for FormData
            success: function (response) {
                alert('Data saved successfully!');
                sessionStorage.clear(); // Clear session data
                // Optionally, reset the button
                jQuery('#finalSubmitsBtn').attr('disabled', false).val('Submit');
            },
            error: function (xhr, status, error) {
                alert('Error: ' + error);
                // Optionally, reset the button
                jQuery('#finalSubmitsBtn').attr('disabled', false).val('Submit');
            }
        });
    });
});

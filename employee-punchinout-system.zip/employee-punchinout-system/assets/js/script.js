// importing navbar and sidebar
jQuery(document).ready(function () {
  const basePath = "/code/phrm/wp-content/plugins/employee-puchinout-system";

  jQuery("#navbar-container").load(`${basePath}/includes/html/navbar.html`);
  jQuery("#sidebar-container").load(`${basePath}/includes/html/sidebar.html`, function () {
    console.log("Sidebar loaded!");

    // Now that sidebar is loaded, we can safely access #icon-list
    const list = document.getElementById("icon-list");
    if (!list) {
      console.error("Error: #icon-list not found!");
      return;
    }

    if (!Array.isArray(data) || data.length === 0) {
      console.error("Error: Data is empty or undefined!");
      return;
    }

    data.forEach((item) => {
      const li = document.createElement("li");
      li.innerHTML = `<a class="text-[#16151C] font-light text-sm sm:text-base ${item.class}" id="${item.id}" href="${item.href}">${item.svg}${item.title}</a>`;
      list.appendChild(li);
    });

     // Insert employee dashboard nav
     const home_url = window.location.origin;
     const dashboardMenuHTML = `
       <ul class="employee-dashboard-menu">
         <li><a href="${home_url}/code/phrm/attendance/">Attendance</a></li>
         <li><a href="${home_url}/code/phrm/apply-for-leave/">Apply for Leave</a></li>
         <li><a href="${home_url}/code/phrm/view-leaves/">View Leaves</a></li>
         <li><a href="${home_url}/code/phrm/view-log/">View Log</a></li>
       </ul>
     `;
const parsedDashboardMenu = dashboardMenuHTML.replace(/{{home_url}}/g, home_url);
jQuery("#sidebar-container").append(parsedDashboardMenu);

console.log("Icons added successfully!");
    console.log("Icons added successfully!");

    // Get the current pathname and remove ".html"
    let pathname = window.location.pathname
      .replace(basePath, "")
      .split("/")
      .pop()
      .replace(".html", "");

    if (pathname == "add-employee") {
      jQuery("#all-employees").addClass("active");
    }

    // Loop through each sidebar item and check if its ID matches the pathname
    jQuery(".sidebar-list-box ul li a").each(function () {
      if (jQuery(this).attr("id") === pathname) {
        jQuery(this).addClass("active");
      }
    });

    // Toggle menu
    jQuery(".toggle-btn").click(function (e) {
      e.preventDefault();
      jQuery("body").addClass("active");
      jQuery(".sidebar-main").addClass("active");
      jQuery(".overlay").addClass("!block");
    });

    jQuery(".menu-toggle-close").click(function (e) {
      e.preventDefault();
      jQuery("body").removeClass("active");
      jQuery(".sidebar-main").removeClass("active");
      jQuery(".overlay").removeClass("!block");
    });

    jQuery(document).click(function (e) {
      // Check if the click is outside .sidebar-main and .toggle-btn
      if (!jQuery(e.target).closest(".sidebar-main, .toggle-btn").length) {
        jQuery("body").removeClass("active");
        jQuery(".sidebar-main").removeClass("active");
        jQuery(".overlay").removeClass("!block");
      }
    });
  });
});


const data = [
  {
    href: "dashboard.html",
    title: "Dashboard",
    id: "index",
    class: "",
    svg: `
                <svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M4 2C2.89543 2 2 2.89543 2 4V8C2 9.10457 2.89543 10 4 10H8C9.10457 10 10 9.10457 10 8V4C10 2.89543 9.10457 2 8 2H4ZM18 10C20.2091 10 22 8.20914 22 6C22 3.79086 20.2091 2 18 2C15.7909 2 14 3.79086 14 6C14 8.20914 15.7909 10 18 10ZM10 18C10 20.2091 8.20914 22 6 22C3.79086 22 2 20.2091 2 18C2 15.7909 3.79086 14 6 14C8.20914 14 10 15.7909 10 18ZM16 14C14.8954 14 14 14.8954 14 16V20C14 21.1046 14.8954 22 16 22H20C21.1046 22 22 21.1046 22 20V16C22 14.8954 21.1046 14 20 14H16Z"/>
</svg>

            `,
  },
  {
    href: "all-employees.html",
    title: "All Employees",
    id: "all-employees",
    class: "",
    svg: `
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<ellipse cx="12" cy="16.5" rx="6" ry="2.5" stroke-width="1.5" stroke-linejoin="round"/>
<circle cx="12" cy="8" r="3" stroke-width="1.5" stroke-linejoin="round"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M6.44547 13.2615C5.20689 13.313 4.06913 13.5361 3.18592 13.8894C2.68122 14.0913 2.22245 14.3505 1.87759 14.6766C1.53115 15.0042 1.25 15.4512 1.25 16C1.25 16.5488 1.53115 16.9958 1.87759 17.3234C2.22245 17.6495 2.68122 17.9087 3.18592 18.1106C3.68571 18.3105 4.26701 18.4687 4.90197 18.5778C4.40834 18.0453 4.09852 17.4503 4.01985 16.8195C3.92341 16.787 3.83104 16.7531 3.74301 16.7179C3.34289 16.5578 3.06943 16.386 2.90826 16.2336C2.7498 16.0837 2.74999 16.0046 2.75 16.0001L2.75 16L2.75 15.9999C2.74999 15.9954 2.7498 15.9163 2.90826 15.7664C3.06943 15.614 3.34289 15.4422 3.74301 15.2821C3.94597 15.201 4.17201 15.1266 4.41787 15.0608C4.83157 14.371 5.53447 13.756 6.44547 13.2615Z" />
<path fill-rule="evenodd" clip-rule="evenodd" d="M19.9803 16.8195C19.9016 17.4503 19.5918 18.0453 19.0982 18.5778C19.7331 18.4687 20.3144 18.3105 20.8142 18.1106C21.3189 17.9087 21.7777 17.6495 22.1226 17.3234C22.469 16.9958 22.7502 16.5488 22.7502 16C22.7502 15.4512 22.469 15.0042 22.1226 14.6766C21.7777 14.3505 21.3189 14.0913 20.8142 13.8894C19.931 13.5361 18.7933 13.313 17.5547 13.2615C18.4657 13.756 19.1686 14.371 19.5823 15.0608C19.8281 15.1266 20.0542 15.201 20.2571 15.2821C20.6573 15.4422 20.9307 15.614 21.0919 15.7664C21.2504 15.9163 21.2502 15.9954 21.2502 15.9999V16V16.0001C21.2502 16.0046 21.2504 16.0837 21.0919 16.2336C20.9307 16.386 20.6573 16.5578 20.2571 16.7179C20.1691 16.7531 20.0767 16.787 19.9803 16.8195Z" />
<path fill-rule="evenodd" clip-rule="evenodd" d="M16.5145 10.1522C16.2946 10.6126 16.0063 11.0341 15.6628 11.4036C16.0587 11.6243 16.5147 11.75 17.0001 11.75C18.5188 11.75 19.7501 10.5188 19.7501 9C19.7501 7.48122 18.5188 6.25 17.0001 6.25C16.8958 6.25 16.7929 6.2558 16.6916 6.26711C16.8637 6.73272 16.9684 7.23096 16.9939 7.75001C16.996 7.75 16.998 7.75 17.0001 7.75C17.6904 7.75 18.2501 8.30964 18.2501 9C18.2501 9.69036 17.6904 10.25 17.0001 10.25C16.8278 10.25 16.6637 10.2152 16.5145 10.1522Z" />
<path fill-rule="evenodd" clip-rule="evenodd" d="M7.30845 6.26711C7.20719 6.2558 7.10427 6.25 7 6.25C5.48122 6.25 4.25 7.48122 4.25 9C4.25 10.5188 5.48122 11.75 7 11.75C7.48537 11.75 7.94138 11.6243 8.33721 11.4036C7.99374 11.0341 7.70549 10.6126 7.4856 10.1522C7.33631 10.2152 7.17222 10.25 7 10.25C6.30964 10.25 5.75 9.69036 5.75 9C5.75 8.30964 6.30964 7.75 7 7.75C7.00205 7.75 7.00409 7.75 7.00614 7.75001C7.0317 7.23096 7.13641 6.73272 7.30845 6.26711Z" />
</svg>


            `,
  },
  {
    href: "#",
    title: "All Departments",
    class: "",
    svg: `
           <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<circle cx="6" cy="4" r="2" stroke-width="1.5"/>
<ellipse cx="6" cy="8" rx="3" ry="2" stroke-width="1.5"/>
<circle cx="18" cy="16" r="2" stroke-width="1.5"/>
<path d="M22 12C22 6.47715 17.5228 2 12 2M12 22C6.47715 22 2 17.5228 2 12" stroke-width="1.5" stroke-linecap="round"/>
<ellipse cx="18" cy="20" rx="3" ry="2" stroke-width="1.5"/>
</svg>

            `,
  },
  {
    href: "#",
    title: "Attendance",
    class: "",
    svg: `
               <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M8 2V5" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M16 2V5" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M3 7.5C3 5.29086 4.79086 3.5 7 3.5H17C19.2091 3.5 21 5.29086 21 7.5V18C21 20.2091 19.2091 22 17 22H7C4.79086 22 3 20.2091 3 18V7.5Z" stroke-width="1.5"/>
<path d="M9 15L10.7528 16.4023C11.1707 16.7366 11.7777 16.6826 12.1301 16.2799L15 13" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M3 9H21" stroke-width="1.5" stroke-linecap="round"/>
</svg>

            `,
  },
  {
    href: "#",
    title: "Payroll",
    class: "",
    svg: `
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<circle cx="12" cy="12" r="10" stroke-width="1.5"/>
<path d="M14 10C14 8.89543 13.1046 8 12 8C10.8954 8 10 8.89543 10 10C10 11.1046 10.8954 12 12 12" stroke-width="1.5" stroke-linecap="round"/>
<path d="M12 12C13.1046 12 14 12.8954 14 14C14 15.1046 13.1046 16 12 16C10.8954 16 10 15.1046 10 14" stroke-width="1.5" stroke-linecap="round"/>
<path d="M12 6.5V8" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M12 16V17.5" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
</svg>

            `,
  },
  {
    href: "leaves.html",
    title: "Leaves",
    id: "leaves",
    class: "",
    svg: `
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M8 10H16M8 14H16M8 18H12M8 4C8 5.10457 8.89543 6 10 6H14C15.1046 6 16 5.10457 16 4M8 4C8 2.89543 8.89543 2 10 2H14C15.1046 2 16 2.89543 16 4M8 4H7C4.79086 4 3 5.79086 3 8V18C3 20.2091 4.79086 22 7 22H17C19.2091 22 21 20.2091 21 18V8C21 5.79086 19.2091 4 17 4H16" stroke-width="1.5" stroke-linecap="round"/>
</svg>

            `,
  },
  {
    href: "#",
    title: "Holidays",
    class: "",
    svg: `
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M17 13H11M17 9H11M17 17H11M16 2V5M8 2V5M7 22H17C19.2091 22 21 20.2091 21 18V7.5C21 5.29086 19.2091 3.5 17 3.5H7C4.79086 3.5 3 5.29086 3 7.5V18C3 20.2091 4.79086 22 7 22Z" stroke-width="1.5" stroke-linecap="round"/>
<path d="M8.5 9C8.5 9.55228 8.05228 10 7.5 10C6.94772 10 6.5 9.55228 6.5 9C6.5 8.44772 6.94772 8 7.5 8C8.05228 8 8.5 8.44772 8.5 9Z"/>
<path d="M8.5 13C8.5 13.5523 8.05228 14 7.5 14C6.94772 14 6.5 13.5523 6.5 13C6.5 12.4477 6.94772 12 7.5 12C8.05228 12 8.5 12.4477 8.5 13Z"/>
<path d="M8.5 17C8.5 17.5523 8.05228 18 7.5 18C6.94772 18 6.5 17.5523 6.5 17C6.5 16.4477 6.94772 16 7.5 16C8.05228 16 8.5 16.4477 8.5 17Z"/>
</svg>

            `,
  },
  {
    href: "#",
    title: "Settings",
    class: "",
    svg: `
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">

</svg>

            `,
  },
];

// add empl tab js
jQuery(document).ready(function () {
  // When a tab button is clicked
  jQuery(".add-empl-tab").on("click", function () {
    var tabName = jQuery(this).data("tab");

    // Remove the active class from all tabs
    jQuery(".add-empl-tab").removeClass("active");

    // Add the active class to the clicked tab
    jQuery(this).addClass("active");

    // Hide all tab content
    jQuery(".tab-content").hide();

    // Show the corresponding tab content
    jQuery("#" + tabName).show();
  });

  // Optionally, you can set the first tab to be active on page load
  jQuery(".add-empl-tab").first().click();
});

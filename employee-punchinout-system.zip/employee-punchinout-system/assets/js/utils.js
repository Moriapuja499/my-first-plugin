jQuery(document).ready(function () {
 //Update Leave status By Admin/Super Admin Or HR
    // Handle Update button click
    jQuery(document).on('click', '.update-leave-status-btn', function() {
        const leaveId = jQuery(this).data('leave-id');
        
        // Get values
        const status = jQuery(`#leave-row-${leaveId} .status-select`).val();
        
        // Make AJAX request to update status in the database
        jQuery.ajax({
            url: eps_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'eps_update_leave_status',
                leave_id: leaveId,
                status: status,  // Pass selected status
                nonce: eps_ajax.nonce_update_leave // Ensure nonce is passed
            },
            success: function(response) {
                if (response.success) {
                    // Update UI to reflect the change
                    jQuery(`#leave-row-${leaveId} .status-select`).replaceWith(`<input type="text" class="status" value="${status}" readonly>`);
                    jQuery(`#leave-row-${leaveId} .update-leave-status-btn`)
                        .text('Updated')
                        .addClass('updated-leave-status-btn')
                        .removeClass('update-leave-status-btn');
                    
                    jQuery('#leaveStatusMessage').html('<p>Leave status updated successfully.</p>');
                } else {
                    jQuery('#leaveStatusMessage').html('<p>Error updating status. Please try again.</p>');
                }
            },
            error: function(error) {
                console.log('AJAX Error:', error);
            }
        });
    });

    jQuery(function ($) {
        const passwordOptionInputs = $('input[name="employee_password_option"]');
        const customPasswordRow = $('#custom-password-row');
    
        passwordOptionInputs.on('change', function () {
            if (this.value === 'custom') {
                customPasswordRow.show();
            } else {
                customPasswordRow.hide();
            }
        });
    });
    
    // document.addEventListener('DOMContentLoaded', function() {
    //     const passwordOptionInputs = document.querySelectorAll('input[name="employee_password_option"]');
    //     const customPasswordRow = document.getElementById('custom-password-row');

    //     passwordOptionInputs.forEach(input => {
    //         input.addEventListener('change', function() {
    //             if (this.value === 'custom') {
    //                 customPasswordRow.style.display = '';
    //             } else {
    //                 customPasswordRow.style.display = 'none';
    //             }
    //         });
    //     });
    // });


// View Employee details in popup
jQuery(document).on('click', '.view-details-btn', function() {
    var row = jQuery(this).closest('tr');
    var empId = row.find('.emp-id').val();
    var name = row.find('.emp-name').val();
    var email = row.find('.emp-email').val();
    var department = row.find('.emp-depart').val();
    var designation = row.find('.emp-desig').val();
    var jobType = row.find('.emp-job_type').val();
    var createdAt = row.find('.emp-add-date').val();

    var detailsHtml = `
        <p><strong>Employee ID:</strong> ${empId}</p>
        <p><strong>Name:</strong> ${name}</p>
        <p><strong>Email:</strong> ${email}</p>
        <p><strong>Department:</strong> ${department}</p>
        <p><strong>Designation:</strong> ${designation}</p>
        <p><strong>Job Type:</strong> ${jobType}</p>
        <p><strong>Created At:</strong> ${createdAt}</p>
    `;

    jQuery('#modalDetails').html(detailsHtml);
    jQuery('#employeeDetailsModal').fadeIn();
});

// Close modal
jQuery(document).on('click', '.close-modal', function() {
    jQuery('#employeeDetailsModal').fadeOut();
});

jQuery('.edit-employee-multistep-btn').on('click', function() {
    let empId = jQuery(this).data('emp-id');
    let targetUrl = eps_ajax.profilePageUrl;
    window.location.href = targetUrl + "&empid=" + empId;
});
});
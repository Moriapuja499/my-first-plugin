jQuery(document).ready(function () {
    let timerInterval;
    let totalElapsedMs = 0;
    let isRunning = false;
    let isPunchedOut = true;
    let lastStartTime;

    function updateDisplay() {
        const elapsed = totalElapsedMs + (isRunning ? new Date() - lastStartTime : 0);
        const hours = String(Math.floor(elapsed / (1000 * 60 * 60))).padStart(2, '0');
        const minutes = String(Math.floor((elapsed % (1000 * 60 * 60)) / (1000 * 60))).padStart(2, '0');
        const seconds = String(Math.floor((elapsed % (1000 * 60)) / 1000)).padStart(2, '0');
        document.getElementById("work-timer-display").textContent = `${hours}:${minutes}:${seconds}`;
        document.getElementById("finalTotalWorkTime").textContent = `${hours}:${minutes}:${seconds}`;
    }

    function startTimer() {
        if (!isRunning && !isPunchedOut) {
            lastStartTime = new Date();
            isRunning = true;
            document.getElementById("live-work-timer").style.display = "block";
            timerInterval = setInterval(updateDisplay, 1000);
            saveToLocalStorage();
        }
    }

    function pauseTimer() {
        if (isRunning) {
            totalElapsedMs += new Date() - lastStartTime;
            isRunning = false;
            clearInterval(timerInterval);
            saveToLocalStorage();
        }
    }

    function punchIn() {
        isPunchedOut = false;
        startTimer();
    }

    function lunchOut() {
        pauseTimer();
    }

    function lunchIn() {
        startTimer();
    }

    function punchOut() {
        pauseTimer();
        isPunchedOut = true;
        saveToLocalStorage();
    }

    function resetAllAtMidnight() {
        totalElapsedMs = 0;
        isRunning = false;
        isPunchedOut = true;
        lastStartTime = null;
        clearInterval(timerInterval);
        document.getElementById("live-work-timer").style.display = "none";
        document.getElementById("work-timer-display").textContent = "00:00:00";
        document.getElementById("finalTotalWorkTime").textContent = "";
        localStorage.removeItem("workTimerData");
        localStorage.setItem("workTimerDate", new Date().toDateString());
    }

    function saveToLocalStorage() {
        const data = {
            totalElapsedMs,
            isRunning,
            isPunchedOut,
            lastStartTime: lastStartTime ? lastStartTime.toISOString() : null
        };
        localStorage.setItem('workTimerData', JSON.stringify(data));
        localStorage.setItem("workTimerDate", new Date().toDateString());
    }

    function loadFromLocalStorage() {
        const today = new Date().toDateString();
        const savedDate = localStorage.getItem("workTimerDate");

        if (savedDate !== today) {
            resetAllAtMidnight();
            return;
        }

        const data = JSON.parse(localStorage.getItem('workTimerData'));
        if (data) {
            totalElapsedMs = data.totalElapsedMs || 0;
            isRunning = data.isRunning;
            isPunchedOut = data.isPunchedOut;
            lastStartTime = data.lastStartTime ? new Date(data.lastStartTime) : null;

            if (isRunning && !isPunchedOut) {
                startTimer();
            } else {
                updateDisplay();
            }

            if (!isPunchedOut) {
                document.getElementById("live-work-timer").style.display = "block";
            }
        }
    }

    // Load previous session
    loadFromLocalStorage();

    // Attach button actions
    document.getElementById("punchInBtn").addEventListener("click", punchIn);
    document.getElementById("lunchOutBtn").addEventListener("click", lunchOut);
    document.getElementById("lunchInBtn").addEventListener("click", lunchIn);
    document.getElementById("punchOutBtn").addEventListener("click", punchOut);


});
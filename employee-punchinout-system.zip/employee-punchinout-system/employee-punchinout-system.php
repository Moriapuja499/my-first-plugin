<?php
/**
 * Plugin Name: Employee Punchinout System
 * Description: Employee Punchinout and Leave Management System
 * Author: Global Studioz | Puja Moria
 * Version: 1.0
 * Author URI: https://globalstudioz.com/
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Start output buffering to suppress accidental output (optional during debugging)
ob_start();

// Define constants
define('EPS_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('EPS_PLUGIN_URL', plugin_dir_url(__FILE__));

// Include required files
require_once EPS_PLUGIN_DIR . 'includes/enqueue-scripts.php';
//require_once EPS_PLUGIN_DIR . 'includes/ajax-handlers.php';
require_once EPS_PLUGIN_DIR . 'includes/templates.php';
require_once EPS_PLUGIN_DIR . 'includes/util-functions.php';
// Shortcodes
foreach (glob(EPS_PLUGIN_DIR . 'includes/shortcodes/*.php') as $file) {
    require_once $file;
}

// AJAX handlers
foreach (glob(EPS_PLUGIN_DIR . 'includes/ajax/*.php') as $file) {
    require_once $file;
}

//Util Files include
foreach (glob(EPS_PLUGIN_DIR . 'includes/utils/*.php') as $file) {
    require_once $file;
}

// Load AJAX handler files
foreach (glob(EPS_PLUGIN_DIR . 'includes/ajax/*.php') as $ajax_file) {
    include_once $ajax_file;
}
// //require_once EPS_PLUGIN_DIR . 'includes/shortcodes.php';
// require_once EPS_PLUGIN_DIR . 'includes/shortcodes/shortcode-dashboard.php';
// require_once EPS_PLUGIN_DIR . 'includes/shortcodes/shortcode-leave-form.php';
// require_once EPS_PLUGIN_DIR . 'includes/shortcodes/shortcode-login.php';
// require_once EPS_PLUGIN_DIR . 'includes/shortcodes/shortcode-punchinout.php';
// require_once EPS_PLUGIN_DIR . 'includes/shortcodes/shortcode-view-attendance.php';
// require_once EPS_PLUGIN_DIR . 'includes/shortcodes/shortcode-view-leaves.php';

require_once EPS_PLUGIN_DIR . 'includes/ajax/ajax-dashboard-loader.php';
//require_once EPS_PLUGIN_DIR . 'includes/ajax/ajax-perform-action.php';
require_once EPS_PLUGIN_DIR . 'includes/database.php';
//require_once EPS_PLUGIN_DIR . 'includes/utilities.php';
require_once EPS_PLUGIN_DIR . 'includes/class-employee-cpt.php';
require_once EPS_PLUGIN_DIR . 'includes/class-employee-admin-menu.php';
require_once EPS_PLUGIN_DIR . 'includes/class-employee-roles.php';
require_once EPS_PLUGIN_DIR . 'includes/class-employee-taxonomies.php';
require_once EPS_PLUGIN_DIR . 'includes/class-employee-utils.php';

// Activation Hook
register_activation_hook(__FILE__, 'eps_activate_plugin');
function eps_activate_plugin() {
    Employee_Roles::add_roles();
    Employee_Roles::add_capabilities();
    //Employee_CPT::create_database_tables();
    eps_create_log_table();
    eps_create_leave_application_table();
    create_eps_management_table();
    create_eps_leave_summary_table();
    create_eps_employees_table();
}

// Deactivation Hook
register_deactivation_hook(__FILE__, 'eps_deactivate_plugin');
function eps_deactivate_plugin() {
    Employee_Roles::remove_roles();
}

// Clean buffer (optional, only for suppressing accidental output)
ob_end_clean();

<?php
if (!defined('ABSPATH')) exit;

function handle_employee_logout() {
    if (isset($_GET['employee_logout']) && $_GET['employee_logout'] == '1') {
        if (!session_id()) session_start();
        session_unset();
        session_destroy();
        wp_redirect(home_url('/employee-login'));
        exit;
    }
}
add_action('init', 'handle_employee_logout');

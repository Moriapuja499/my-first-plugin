<?php
if (!defined('ABSPATH')) exit;

function handle_employee_login() {
    if (!isset($_POST['employee_login'])) return;

    global $wpdb;
    $employee_name = sanitize_text_field($_POST['employee_name']);
    $employee_id = sanitize_text_field($_POST['employee_id']);
    $password  = $_POST['password'];

    $table_name = $wpdb->prefix . 'employees';
    $employee = $wpdb->get_row(
        $wpdb->prepare("SELECT * FROM $table_name WHERE empid = %s AND name = %s", $employee_id, $employee_name)
    );

    if ($employee && wp_check_password($password, $employee->password)) {
        $_SESSION['employee_id'] = $employee->empid;
        $_SESSION['employee_name'] = $employee->name;
        session_write_close();
        wp_redirect(home_url('/attendance'));
        exit;
    } else {
        $_SESSION['login_error'] = 'Invalid login credentials. Please try again.';
        wp_redirect(home_url());
        exit;
    }
}
add_action('init', 'handle_employee_login');

<?php
if (!defined('ABSPATH')) exit;

add_filter('render_block', 'eps_dynamic_employee_login_logout_nav', 10, 2);
function eps_dynamic_employee_login_logout_nav($block_content, $block) {
    if ($block['blockName'] === 'core/navigation') {
        if (!session_id()) session_start();

        $is_logged_in = isset($_SESSION['employee_id']);
        $login_url = esc_url(home_url('/employee-login'));
        $logout_url = esc_url(add_query_arg('employee_logout', '1', home_url()));

        $block_content = str_replace('<a href="' . $login_url . '">Employee Login</a>', '', $block_content);
        $block_content = str_replace('<a href="' . $logout_url . '">Logout</a>', '', $block_content);

        $block_content .= '<li class="wp-block-navigation-item"><a href="' . ($is_logged_in ? $logout_url : $login_url) . '">' . ($is_logged_in ? 'Logout' : 'Employee Login') . '</a></li>';
    }
    return $block_content;
}

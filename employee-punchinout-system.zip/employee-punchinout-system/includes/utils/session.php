<?php
if (!defined('ABSPATH')) exit;

function eps_start_session() {
    if (session_status() === PHP_SESSION_NONE) {
        // Set session lifetime to 30 days (2592000 seconds)
        ini_set('session.gc_maxlifetime', 2592000);
        ini_set('session.cookie_lifetime', 2592000);
        session_set_cookie_params(2592000);
        session_start();
    }
}
add_action('init', 'eps_start_session', 1);


<?php
if (!defined('ABSPATH')) exit;
function eps_update_leave_summary($empid, $leave_type, $date_applied) {
    global $wpdb;
    $table = $wpdb->prefix . 'eps_leave_summary';

    $year = date('Y', strtotime($date_applied));
    $month = date('n', strtotime($date_applied));

    // Check if a summary already exists
    $summary = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $table WHERE empid = %d AND year = %d AND month = %d",
        $empid, $year, $month
    ));

    // If not, insert initial row with carry forward logic
    if (!$summary) {
        // Get previous month's summary
        $prev = $wpdb->get_row($wpdb->prepare(
            "SELECT full_day_allowed, full_day_taken, full_day_carry_forward FROM $table 
             WHERE empid = %d AND (year < %d OR (year = %d AND month < %d)) 
             ORDER BY year DESC, month DESC LIMIT 1",
            $empid, $year, $year, $month
        ));

        // Calculate carry forward (max 1 full day unused from previous month)
        $carry_forward = 0;
        if ($prev) {
            $previous_available = intval($prev->full_day_allowed) + intval($prev->full_day_carry_forward);
            $remaining = max(0, $previous_available - intval($prev->full_day_taken));
            $carry_forward = min(1, $remaining);
        }

        // Insert new row for current month
        $wpdb->insert($table, [
            'empid' => $empid,
            'year' => $year,
            'month' => $month,
            'full_day_allowed' => 1,
            'short_leave_allowed' => 2,
            'full_day_carry_forward' => $carry_forward,
            'full_day_taken' => 0,
            'half_day_taken' => 0,
            'short_leave_taken' => 0,
            'total_leaves_taken' => 0,
        ]);
    }

    // Set increments based on leave type
    $leave_increment = 0;
    $update_fields = [];

    if ($leave_type === 'fullday') {
        $leave_increment = 1;
        $update_fields[] = "full_day_taken = full_day_taken + 1";
    } elseif ($leave_type === 'halfday' || $leave_type === 'half') {
        $leave_increment = 0.5;
        $update_fields[] = "half_day_taken = half_day_taken + 1";
    } elseif ($leave_type === 'shortleave' || $leave_type === 'short') {
        $leave_increment = 0.25;
        $update_fields[] = "short_leave_taken = short_leave_taken + 1";
    }

    $update_fields[] = "total_leaves_taken = total_leaves_taken + {$leave_increment}";

    // Apply update
    $wpdb->query($wpdb->prepare(
        "UPDATE $table SET " . implode(', ', $update_fields) . " 
         WHERE empid = %d AND year = %d AND month = %d",
        $empid, $year, $month
    ));
}

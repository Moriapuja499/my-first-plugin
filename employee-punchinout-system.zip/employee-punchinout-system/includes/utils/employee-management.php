<?php
if (!defined('ABSPATH')) exit;
//Employee Management Page
function eps_employee_management_page() 
{
    //if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['eps_update_employee_nonce']) && wp_verify_nonce($_POST['eps_update_employee_nonce'], 'eps_update_employee')) {
        // $user_id = get_current_user_id();
        //include 'adminpages/employee_management.php';  
        include dirname(__DIR__) . '/adminpages/employee_management.php';
}

//Employees Attendance data
function eps_attendance_info_page(){
    include dirname(__DIR__) . '/adminpages/attendance_info_list.php';
    //include 'adminpages/attendance_info_list.php';
}

//Employees Attendance record
function eps_attendance_record_page(){
    global $wpdb;
    $summary_table = $wpdb->prefix . 'eps_leave_summary';
    $employee_table = $wpdb->prefix . 'employees';

    $leaves_summarydata = $wpdb->get_results("
        SELECT s.*, e.name 
        FROM $summary_table s
        LEFT JOIN $employee_table e ON s.empid = e.empid
        ORDER BY s.year DESC, s.month DESC, s.empid
    ");

    echo eps_load_admin_template('attendance_record.php', ['leaves_summarydata' => $leaves_summarydata]);
    //include 'adminpages/attendance_record.php';
}

//Employee Leaves data

function eps_leave_info_page(){
   
    include dirname(__DIR__) . '/adminpages/leaves_info_list.php';
    //include 'adminpages/leaves_info_list.php';
}

//Load Edit Employee Form
add_action('wp_ajax_load_employee_edit_form', 'load_employee_edit_form');

function load_employee_edit_form() {
    check_ajax_referer('eps_editemp_nonce', 'security');

    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => 'Unauthorized access']);
    }



    // Get the employee ID
    $emp_id = intval($_POST['employee_id']); 
    if ($emp_id <= 0) {
        wp_send_json_error(['message' => 'Invalid Employee ID']);
    }

    // Fetch employee data
    global $wpdb;
    $table_name = $wpdb->prefix . 'eps_employees_data';
    $edit_emp_data = !empty($emp_id) ? $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE emp_id = %d", $emp_id)) : null;
    // Check if data exists
    if (!$edit_emp_data) {
        wp_send_json_error(['message' => 'Employee not found']);
    }

    ob_start();
    echo eps_load_admin_template('employee-edit-multistep.php', ['emp_id' => $emp_id, 'edit_emp_data' => $edit_emp_data]);
    //include plugin_dir_path(__FILE__) . 'adminpages/employee-edit-multistep.php'; // Include the form template
    wp_send_json_success(['html' => ob_get_clean()]);
}
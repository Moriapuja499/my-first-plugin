<?php
if (!defined('ABSPATH')) exit;
function eps_add_profile_management_menu() {
    if (current_user_can('read')) {
        add_menu_page(
            'Profile Management',
            'Profile Management',
            'read',
            'eps_profile_management',
            'eps_personal_info_page',
            'dashicons-admin-users',
            6
        );
      
    }
}
add_action('admin_menu', 'eps_add_profile_management_menu');

function eps_personal_info_page() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'employees';
    $employees_data = $wpdb->get_results("SELECT empid, name FROM $table_name");

    echo eps_load_admin_template('personalinfo.php', ['employees_data' => $employees_data]);
}

add_action('admin_init', 'eps_handle_form_submission');
function eps_handle_form_submission() {
    if (!isset($_POST['eps_management_nonce']) || !wp_verify_nonce($_POST['eps_management_nonce'], 'eps_management_form')) {
        return;
    }

    if (!session_id()) session_start();

    $current_step = $_POST['current_step'] ?? 1;

    switch ($current_step) {
        case 1:
            $_SESSION['personal_info'] = [
                'first_name' => sanitize_text_field($_POST['first_name']),
                'last_name' => sanitize_text_field($_POST['last_name']),
                'mobile' => sanitize_text_field($_POST['mobile']),
                'email' => sanitize_email($_POST['email']),
                'dob' => sanitize_text_field($_POST['dob']),
                'marital_status' => sanitize_text_field($_POST['marital_status']),
                'gender' => sanitize_text_field($_POST['gender']),
                'nationality' => sanitize_text_field($_POST['nationality']),
                'address' => sanitize_textarea_field($_POST['address']),
                'city' => sanitize_text_field($_POST['city']),
                'state' => sanitize_text_field($_POST['state']),
                'zipcode' => sanitize_text_field($_POST['zipcode']),
                'profile_picture' => $_POST['existing_profile_picture'] ?? ''
            ];

            // Handle new file upload
            if (!empty($_FILES['profile_picture']['name'])) {
                $upload = wp_handle_upload($_FILES['profile_picture'], ['test_form' => false]);
                if (!isset($upload['error'])) {
                    $_SESSION['personal_info']['profile_picture'] = $upload['url'];
                }
            }

            $_SESSION['current_step'] = 2;
            break;

        case 2:
            $_SESSION['professional_info'] = [
                'experience' => sanitize_text_field($_POST['experience']),
                'certification' => sanitize_text_field($_POST['certification']),
            ];
            $_SESSION['current_step'] = 3;
            break;

        case 3:
            $_SESSION['account_access'] = [
                'slackid' => sanitize_text_field($_POST['slackid']),
                'skypeid' => sanitize_text_field($_POST['skypeid']),
                'githubid' => sanitize_text_field($_POST['githubid']),
            ];
            $_SESSION['current_step'] = 4;
            break;

        case 4:
            if (!isset($_POST['eps_employee_details_nonce']) || !wp_verify_nonce($_POST['eps_employee_details_nonce'], 'eps_profile_step4_action')) {
                return;
            }

            global $wpdb;
            $table = $wpdb->prefix . 'eps_employees_data';
            $employee_id = intval($_POST['employee_id']);

            $data = [
                'emp_id' => $employee_id,
                'personal_info' => wp_json_encode($_SESSION['personal_info']),
                'professional_info' => wp_json_encode($_SESSION['professional_info']),
                'account_access' => wp_json_encode($_SESSION['account_access']),
            ];

            $exists = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table WHERE emp_id = %d", $employee_id));
            if ($exists) {
                $wpdb->update($table, $data, ['emp_id' => $employee_id]);
            } else {
                $wpdb->insert($table, $data);
            }

            // Clear session and redirect or reset step
            unset($_SESSION['personal_info'], $_SESSION['professional_info'], $_SESSION['account_access']);
            $_SESSION['current_step'] = 1;
            wp_redirect(admin_url('admin.php?page=employee-punchinout-system'));
            exit;
    }
}

// Handle form submissions for profile management
add_action('admin_post_eps_handle_editempform_submission', 'eps_handle_editempform_submission');

function eps_handle_editempform_submission() {
    if (!isset($_POST['eps_editemp_nonce']) || !wp_verify_nonce($_POST['eps_editemp_nonce'], 'eps_editemp_form')) {
        wp_die('Security check failed.');
    }

    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    $edit_current_step = isset($_POST['edit_current_step']) ? intval($_POST['edit_current_step']) : 1;

    switch ($edit_current_step) {
        case 1:
            $_SESSION['em_personal_info'] = [
                'first_name' => sanitize_text_field($_POST['edit_first_name']),
                'last_name' => sanitize_text_field($_POST['edit_last_name']),
                'mobile' => sanitize_text_field($_POST['edit_mobile']),
                'email' => sanitize_email($_POST['edit_email']),
                'dob' => sanitize_text_field($_POST['edit_dob']),
                'marital_status' => sanitize_text_field($_POST['edit_marital_status']),
                'gender' => sanitize_text_field($_POST['edit_gender']),
                'nationality' => sanitize_text_field($_POST['edit_nationality']),
                'address' => sanitize_textarea_field($_POST['edit_address']),
                'city' => sanitize_text_field($_POST['edit_city']),
                'state' => sanitize_text_field($_POST['edit_state']),
                'zipcode' => sanitize_text_field($_POST['edit_zipcode']),
                'profile_picture' => $_POST['edit_existing_profile_picture'] ?? ''
            ];

            // Handle new file upload
            if (!empty($_FILES['edit_profile_picture']['name'])) {
                $upload = wp_handle_upload($_FILES['edit_profile_picture'], ['test_form' => false]);
                if (!isset($upload['error'])) {
                    $_SESSION['em_personal_info']['profile_picture'] = $upload['url'];
                }
            }

            $_SESSION['edit_current_step'] = 2;
            wp_redirect(admin_url('admin.php?page=employee-edit-step2'));
            exit;

        case 2:
            $_SESSION['em_professional_info'] = [
                'experience' => sanitize_text_field($_POST['edit_experience']),
                'certification' => sanitize_text_field($_POST['edit_certification']),
            ];
            $_SESSION['edit_current_step'] = 3;
            wp_redirect(admin_url('admin.php?page=employee-edit-step3'));
            exit;

        case 3:
            $_SESSION['em_account_access'] = [
                'slackid' => sanitize_text_field($_POST['edit_slackid']),
                'skypeid' => sanitize_text_field($_POST['edit_skypeid']),
                'githubid' => sanitize_text_field($_POST['edit_githubid']),
            ];
            $_SESSION['edit_current_step'] = 4;
            wp_redirect(admin_url('admin.php?page=employee-edit-step4'));
            exit;

        case 4:
            if (!isset($_POST['eps_edit_employee_details_nonce']) || !wp_verify_nonce($_POST['eps_edit_employee_details_nonce'], 'eps_edit_profile_step4_action')) {
                wp_die('Security check failed.');
            }

            global $wpdb;
            $table = $wpdb->prefix . 'eps_employees_data';
            $employee_id = intval($_POST['employee_id']);

            $data = [
                'emp_id' => $employee_id,
                'personal_info' => wp_json_encode($_SESSION['em_personal_info']),
                'professional_info' => wp_json_encode($_SESSION['em_professional_info']),
                'account_access' => wp_json_encode($_SESSION['em_account_access']),
            ];

            $exists = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table WHERE emp_id = %d", $employee_id));
            if ($exists) {
                $wpdb->update($table, $data, ['emp_id' => $employee_id]);
            } else {
                $wpdb->insert($table, $data);
            }

            // Clear session and redirect
            unset($_SESSION['em_personal_info'], $_SESSION['em_professional_info'], $_SESSION['em_account_access']);
            $_SESSION['edit_current_step'] = 1;
            wp_redirect(admin_url('admin.php?page=employee-punchinout-system'));
            exit;

        default:
            wp_die('Invalid step.');
    }
}
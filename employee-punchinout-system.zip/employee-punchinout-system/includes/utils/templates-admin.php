<?php
if (!defined('ABSPATH')) exit;

function eps_load_admin_template($file_name, $variables = []) {
    //$file_path = dirname(__DIR__) . 'adminpages/' . $file_name;
    $file_path = dirname(__DIR__) . '/adminpages/' . $file_name;

    if (!file_exists($file_path)) {
        return '<p>Template not found: ' . esc_html($file_name) . '</p>';
    }

    extract($variables);
    ob_start();
    include $file_path;
    return ob_get_clean();
}


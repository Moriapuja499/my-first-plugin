<?php
if (!defined('ABSPATH')) {
    exit;
}

// Create Log Table
function eps_create_log_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'eps_log';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id int(11) NOT NULL AUTO_INCREMENT,
        user_id bigint(20) NOT NULL,
        log_entries longtext NOT NULL,
        total_work_time varchar(255) DEFAULT NULL,
        total_lunch_time varchar(255) DEFAULT NULL,
        log_date date NOT NULL,
        PRIMARY KEY (id),
        UNIQUE KEY user_log_date (user_id, log_date)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

// Create Leave Application Table
function eps_create_leave_application_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'eps_leave_applications';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        leave_id int(11) NOT NULL AUTO_INCREMENT,
        user_id bigint(20) NOT NULL,
        subject varchar(155) NOT NULL,
        from_date date NOT NULL,
        to_date date NOT NULL,
        reason text NOT NULL,
        leave_type text NOT NULL,
        half_day_type text DEFAULT NULL,
        short_leave_time text DEFAULT NULL,
        leaves_log longtext DEFAULT NULL,
        date_applied datetime NOT NULL,
       PRIMARY KEY (leave_id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

function create_eps_management_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'eps_employees_data';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id INT NOT NULL AUTO_INCREMENT,
        emp_id BIGINT NOT NULL,
        personal_info LONGTEXT NOT NULL,
        professional_info LONGTEXT NOT NULL,
        account_access LONGTEXT NOT NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";
    
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql);
}
function create_eps_leave_summary_table() {
    
    global $wpdb;
    $table_name = $wpdb->prefix . 'eps_leave_summary';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id BIGINT AUTO_INCREMENT PRIMARY KEY,
        empid BIGINT NOT NULL,
        year INT NOT NULL,
        month INT NOT NULL,
        full_day_allowed INT DEFAULT 1,
        full_day_taken INT DEFAULT 0,
        full_day_carry_forward INT DEFAULT 0,
        short_leave_allowed INT DEFAULT 2,
        short_leave_taken INT DEFAULT 0,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY unique_emp_month (empid, year, month)
        ) $charset_collate;";

require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql);
}
function create_eps_employees_table() {
    
    global $wpdb;
    $table_name = $wpdb->prefix . 'employees';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        empid VARCHAR(50) NOT NULL PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL,
        department VARCHAR(255),
        designation VARCHAR(255),
        job_type VARCHAR(255),
        password VARCHAR(255),
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP NOT NULL
    ) $charset_collate;";
    
require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql);
}
?>
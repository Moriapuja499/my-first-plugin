<?php
function eps_load_template($file_name, $variables = []) {
    $file_path = plugin_dir_path(__FILE__, 2) . 'empages/' . $file_name;
    if (!file_exists($file_path)) return '<p>Template not found.</p>';

    $content = file_get_contents($file_path);
    foreach ($variables as $key => $value) {
        $content = str_replace('{{' . $key . '}}', $value, $content);
    }
    return $content;
}

function eps_employees_template($file_name, $variables = []) {
    $file_path = plugin_dir_path(__FILE__, 2) . 'empages/' . $file_name;
    if (!file_exists($file_path)) return '<p>Template not found.</p>';

    extract($variables);
    ob_start();
    include $file_path;
    return do_shortcode(ob_get_clean());
}

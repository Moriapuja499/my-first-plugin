<?php
function eps_my_attendance_view() {
    if (!isset($_SESSION['employee_id']) || !isset($_SESSION['employee_name'])) {
        return '<p>You must be logged in to access the punch-in system.</p>';
    }

    global $wpdb;
    $employee_id = $_SESSION['employee_id'];
    $table_name = $wpdb->prefix . 'eps_log';
    $attendance_record = $wpdb->get_results(
        $wpdb->prepare("SELECT * FROM $table_name WHERE user_id = %d ORDER BY $table_name.log_date DESC", $employee_id)
    );

    return eps_employees_template('view_attendance.php', ['attendance_record' => $attendance_record]);
}
add_shortcode('view_attendance', 'eps_my_attendance_view');
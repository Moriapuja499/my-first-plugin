<?php
function eps_leave_application_form() {
    if (!isset($_SESSION['employee_id']) || !isset($_SESSION['employee_name'])) {
        return '<p>You must be logged in to access the punch-in system.</p>';
    }
    
    return eps_load_template('leave_application_form.html');
}
add_shortcode('eps_leave_application_form', 'eps_leave_application_form');
<?php
// Custom Dashboard
function eps_custom_dashboard() {
    //session_start();
    if(isset($_SESSION['employee_id']) || isset($_SESSION['employee_name']) ){
        $emp_id = $_SESSION['employee_id'];
        $emp_name = $_SESSION['employee_name'];
        $variables = [
                    'display_name' =>  $emp_name,
                    'home_url' => home_url()
                ];
                //include plugin_dir_path(__FILE__) . 'dashboard.php';
                return eps_dashload_template('dashboard.html', $variables);
    } else {
            return '<p>You do not have permission to view this page.</p>';
        }
       
}
add_shortcode('eps_custom_dashboard', 'eps_custom_dashboard');
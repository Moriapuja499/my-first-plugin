<?php
// Shortcode to display the Leave Applications
function eps_view_leave_applications() {
    if (!isset($_SESSION['employee_id'])) {
        return '<p>You need to log in to view your leave applications.</p>';
    }

    global $wpdb;
    $employee_id = $_SESSION['employee_id'];
    $table_name = $wpdb->prefix . 'eps_leave_applications';

    $leave_applications = $wpdb->get_results(
        $wpdb->prepare("SELECT * FROM $table_name WHERE user_id = %d ORDER BY date_applied DESC", $employee_id)
    );

    return eps_employees_template('view_leave_applications.php', ['leave_applications' => $leave_applications]);
}
add_shortcode('eps_view_leave_applications', 'eps_view_leave_applications');
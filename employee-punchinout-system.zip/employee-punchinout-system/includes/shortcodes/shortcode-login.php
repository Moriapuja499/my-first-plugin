<?php
function employee_login_form_shortcode() {
    if (isset($_SESSION['employee_id'])) {
        return '<p>You are already logged in.</p>';
    }
    return eps_load_template('employee_login_form.php');
}
add_shortcode('employee_login_form', 'employee_login_form_shortcode');
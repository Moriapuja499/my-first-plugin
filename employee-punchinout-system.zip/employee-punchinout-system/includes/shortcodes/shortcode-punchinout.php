<?php
function eps_punchinout_system() {
    //session_start();
    if (!isset($_SESSION['employee_id']) || !isset($_SESSION['employee_name'])) {
        return '<p>You must be logged in to access the punch-in system.</p>';
    }
    
    $employee_name = $_SESSION['employee_name']; // prevent unsafe characters
    $log_file_url = plugin_dir_url(__DIR__) . 'ajax/logs/' . $employee_name . '_log.txt';

    $variables = [
        'log_file_url' => esc_url($log_file_url),
        'employee_name' => esc_html($employee_name),
        'employee_id' => esc_html($_SESSION['employee_id']),
    ];
    return eps_load_template('punchin_system.html', $variables);
}
add_shortcode('employee_punchinout_system', 'eps_punchinout_system');
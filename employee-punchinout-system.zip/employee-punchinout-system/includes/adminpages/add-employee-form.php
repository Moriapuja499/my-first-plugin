<?php
if (isset($_POST['submit_employee'])) {
    Employee_Admin_Menu::save_employee_data();
    return; // Stop execution to allow wp_redirect in save_employee_data to work
}
$editing = false;
$existing_data = [
    'employee_id' => '',
    'employee_name' => '',
    'employee_email' => '',
    'employee_department' => '',
    'employee_designation' => '',
    'employee_job_type' => ''
];

if (isset($_GET['edit_empid'])) {
    global $wpdb;
    $empid = sanitize_text_field($_GET['edit_empid']);
    $table = $wpdb->prefix . 'employees';
    $employee = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE empid = %s", $empid), ARRAY_A);

    if ($employee) {
        $editing = true;
        $existing_data = [
            'employee_id' => $employee['empid'],
            'employee_name' => $employee['name'],
            'employee_email' => $employee['email'],
            'employee_department' => $employee['department'],
            'employee_designation' => $employee['designation'],
            'employee_job_type' => $employee['job_type']
        ];
    }
}

if (isset($_GET['updated']) && $_GET['updated'] == 1) {
    echo '<div class="updated"><p>' . __('Employee updated successfully.', 'employee-punchinout-system') . '</p></div>';
}



$departments = Employee_Utils::get_terms_for_dropdown('department');
$designations = Employee_Utils::get_terms_for_dropdown('designation');
$job_types = Employee_Utils::get_terms_for_dropdown('job_type');
?>

<h1><?php echo $editing ? __('Edit Employee', 'employee-punchinout-system') : __('Add New Employee', 'employee-punchinout-system'); ?></h1>

<form method="post" action="">
    <?php wp_nonce_field('save_employee', 'employee_nonce'); ?>
    <input type="hidden" name="action_type" value="<?php echo $editing ? 'update' : 'add'; ?>">

    <table class="form-table">
        <tr>
            <th><label for="employee_id"><?php _e('Employee ID', 'employee-punchinout-system'); ?></label></th>
            <td><input type="text" name="employee_id" id="employee_id" value="<?php echo esc_attr($existing_data['employee_id']); ?>" placeholder="EmployeeId"></td>
        </tr>
        <tr>
            <th><label for="employee_name"><?php _e('Name', 'employee-punchinout-system'); ?></label></th>
            <td><input type="text" name="employee_name" id="employee_name" value="<?php echo esc_attr($existing_data['employee_name']); ?>" placeholder="EmployeeName" required></td>
        </tr>
        <tr>
            <th><label for="employee_email"><?php _e('Email', 'employee-punchinout-system'); ?></label></th>
            <td><input type="email" name="employee_email" id="employee_email" value="<?php echo esc_attr($existing_data['employee_email']); ?>" placeholder="EmployeeEmail"required></td>
        </tr>
        <tr>
            <th><label for="employee_password_option"><?php _e('Password Option', 'employee-punchinout-system'); ?></label></th>
            <td>
                <label><input type="radio" name="employee_password_option" value="generate" checked> <?php _e('Generate Password', 'employee-punchinout-system'); ?></label><br>
                <label><input type="radio" name="employee_password_option" value="custom"> <?php _e('Enter Custom Password', 'employee-punchinout-system'); ?></label>
            </td>
        </tr>
        <tr id="custom-password-row" style="display: none;">
            <th><label for="employee_password"><?php _e('Custom Password', 'employee-punchinout-system'); ?></label></th>
            <td><input type="password" name="employee_password" id="employee_password" placeholder="password"></td>
        </tr>
        <tr>
            <th><label for="employee_department"><?php _e('Department', 'employee-punchinout-system'); ?></label></th>
            <td>
                <select name="employee_department" id="employee_department" required>
                    <option value=""><?php _e('Select Department', 'employee-punchinout-system'); ?></option>
                    <?php foreach ($departments as $id => $name) : ?>
                        <option value="<?php echo esc_attr($id); ?>" <?php selected($id, $existing_data['employee_department']); ?>><?php echo esc_html($name); ?></option>
                    <?php endforeach; ?>
                </select>
            </td>
        </tr>
        <tr>
            <th><label for="employee_designation"><?php _e('Designation', 'employee-punchinout-system'); ?></label></th>
            <td>
                <select name="employee_designation" id="employee_designation" required>
                    <option value=""><?php _e('Select Designation', 'employee-punchinout-system'); ?></option>
                    <?php foreach ($designations as $id => $name) : ?>
                        <option value="<?php echo esc_attr($id); ?>" <?php selected($id, $existing_data['employee_designation']); ?>><?php echo esc_html($name); ?></option>
                    <?php endforeach; ?>
                </select>
            </td>
        </tr>
        <tr>
            <th><label for="employee_job_type"><?php _e('Job Type', 'employee-punchinout-system'); ?></label></th>
            <td>
                <select name="employee_job_type" id="employee_job_type" required>
                    <option value=""><?php _e('Select Job Type', 'employee-punchinout-system'); ?></option>
                    <?php foreach ($job_types as $id => $name) : ?>
                        <option value="<?php echo esc_attr($id); ?>" <?php selected($id, $existing_data['employee_job_type']); ?>><?php echo esc_html($name); ?></option>
                    <?php endforeach; ?>
                </select>
            </td>
        </tr>
    </table>

    <p class="submit">
        <input type="submit" name="submit_employee" class="button-primary" value="<?php echo $editing ? __('Update Employee', 'employee-punchinout-system') : __('Save Employee', 'employee-punchinout-system'); ?>">
        <?php if ($editing): ?>
            <input type="submit" name="submit_employee_delete" class="button-secondary" value="<?php _e('Delete Employee', 'employee-punchinout-system'); ?>" onclick="return confirm('Are you sure you want to delete this employee?');">
            <input type="hidden" name="action_type" value="delete" id="delete-action">
        <?php endif; ?>
    </p>
</form>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        const passwordOptions = document.querySelectorAll('input[name="employee_password_option"]');
        const customPasswordRow = document.getElementById('custom-password-row');

        passwordOptions.forEach(function (option) {
            option.addEventListener('change', function () {
                customPasswordRow.style.display = this.value === 'custom' ? '' : 'none';
            });
        });

        const deleteButton = document.querySelector('input[name="submit_employee_delete"]');
        if (deleteButton) {
            deleteButton.addEventListener('click', function () {
                document.querySelector('input[name="action_type"]').value = 'delete';
            });
        }
    });
</script>

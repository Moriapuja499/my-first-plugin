<?php 
if (!is_user_logged_in()) {
        return '<p>You need to log in to view your leave applications.</p>';
    }

    $user_id = get_current_user_id();
    if ($user_id != 1) {
        return '<p>You do not have permission to view this page.</p>';
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'employees';
    $entries = $wpdb->get_results("SELECT * FROM $table_name ORDER BY empid DESC;");

    if ($entries) {
        ob_start();
        ?>
        <h2>List Of Employees</h2>
        <div id="employeeListTable_wrapper">
            <table id="employeeListTable">
                <thead>
                    <tr>
                        <th>Employee Id</th>
                        <th>Employee Name</th>
                        <th>Email</th>
                        <th>Department</th>
                        <th>Designation</th>
                        <th>Job type</th>
                        <th>Created At</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($entries as $entry): ?>
                        <tr id="emp-row-<?php echo esc_attr($entry->empid); ?>">
                            <td><input type="text" class="emp-id" value="<?php echo esc_html($entry->empid); ?>" readonly></td>
                            <td><input type="text" class="emp-name" value="<?php echo esc_html($entry->name); ?>" readonly></td>
                            <td><input type="text" class="emp-email" value="<?php echo esc_html($entry->email); ?>" readonly></td>
                            <td><input type="text" class="emp-depart" value="<?php echo esc_html($entry->department); ?>" readonly></td>
                            <td><input type="text" class="emp-desig" value="<?php echo esc_html($entry->designation); ?>" readonly></td>
                            <td><input type="text" class="emp-job_type" value="<?php echo esc_html($entry->job_type); ?>" readonly></td>
                            <td><input type="text" class="emp-add-date" value="<?php echo esc_html($entry->created_at); ?>" readonly></td>
                            <td>
                                <button class="view-details-btn" data-emp-id="<?php echo esc_attr($entry->empid); ?>">View Details</button>
                                <button class="edit-employee-multistep-btn" data-emp-id="<?php echo esc_attr($entry->empid); ?>">Edit</button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <!-- Employee Details Modal -->
        <div id="employeeDetailsModal" style="display:none;">
            <div class="modal-content">
                <span class="close-modal" style="float:right;cursor:pointer;">&times;</span>
                <h3>Employee Details</h3>
                <div id="modalDetails">
                    <!-- Content will be injected here -->
                </div>
            </div>
        </div>

        <!-- Multi-Step Edit Modal -->
        <div id="employeeMultiStepModal" style="display:none;">
            <div class="modal-content" id="multiStepModalContent">
                <!-- Multi-step form will be loaded here -->
            </div>
            <button class="modal-close">Close</button>
        </div>

        <div id="empStatusMessage"></div>
        <?php
       // return ob_get_clean();
    } else {
        return '<p>No employee records found.</p>';
    }
<?php
global $wpdb;
$user_id = get_current_user_id();
if($user_id == 1){
$table_name = $wpdb->prefix . 'users';
$table_name2 = $wpdb->prefix . 'eps_log';
$entries = $wpdb->get_results(
        $wpdb->prepare(
            "SELECT $table_name.ID, $table_name.user_login,$table_name2.log_date, $table_name2.total_work_time, $table_name2.total_lunch_time
            FROM $table_name
            LEFT JOIN $table_name2 ON $table_name.ID = $table_name2.user_id
            WHERE $table_name.ID != %d
            ORDER BY $table_name.user_login;",
            1 // safely escape and bind the parameter
        )
    );

// echo plugin_dir_path(__FILE__) . 'adminpages/';
echo '<h2>Attendance Overview</h2>';
echo '<table border="1">';
echo '<tr><th>Employee Id</th><th>Date</th><th>Employee Name</th><th>Total Work Time</th><th>Total Lunch Time</th></tr>';
foreach ($entries as $entry) {
    echo '<tr>';
    echo '<td>'.$entry->ID.'</td>';
    echo '<td>'.$entry->log_date.'</td>';
    echo '<td>'.$entry->user_login.'</td>';
    echo '<td>'.$entry->total_work_time.'</td>';
    echo '<td>'.$entry->total_lunch_time.'</td>';
   
    echo '</tr>';
    //echo '<p>User ID: ' . $entry->user_id . ' | Log Entries: ' . $entry->log_entries . ' | Total Work Time: ' . $entry->total_work_time . ' | Total Lunch Time: ' . $entry->total_lunch_time . ' | Date: ' . $entry->log_date . '</p>';
}
echo '</table>';

//echo do_shortcode('[employee_punchinout_system]');
//}
} 
?>
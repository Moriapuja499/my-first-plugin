<?php
   if (!is_user_logged_in()) {
    return '<p>You need to log in to view your leave applications.</p>';
}

$user_id = get_current_user_id();
global $wpdb;
if($user_id == 1){
$table_name = $wpdb->prefix . 'employees';
$table_name2 = $wpdb->prefix . 'eps_log';

$entries = $wpdb->get_results(
    $wpdb->prepare(
        "SELECT $table_name.empid, $table_name.name, $table_name.email, $table_name.department, $table_name.designation, $table_name.job_type, $table_name.created_at, 
                $table_name2.id, $table_name2.user_id, $table_name2.log_entries, $table_name2.total_work_time, $table_name2.total_lunch_time, $table_name2.log_date
        FROM $table_name
        LEFT JOIN $table_name2 ON $table_name.empid = $table_name2.user_id
        WHERE $table_name.empid != %d
        ORDER BY $table_name2.log_date DESC;",
        1
    )
);


    if ($entries) {
        ob_start(); ?>
        <div id="employeeDetailsModal" style="display:none;">
    <div id="modalDetails"></div>
    <button class="close-modal">Close</button>
</div>
    <h2>Attendance of employees</h2>
    <label for="filterYear">Year:</label>
            <select id="filterYear">
                <option value="">All Years</option>
            </select>

            <label for="filterMonth">Month:</label>
            <select id="filterMonth">
                <option value="">All Months</option>
            </select>
            <label for="filterEmployee">Employee Name or ID:</label>
            <input type="text" id="filterEmployee" placeholder="Search by Employee Name or ID">
            <button id="resetFilters">Reset Filters</button>
    <table id="attendanceViewTable" class="display">
            <thead>
                <tr>
                    <th>Employee Id</th>
                    <th>Date</th>
                    <th>Employee Name</th>
                    <th>Punchin</th>
                    <th>Punchout</th>
                    <!-- <th>Log Entries</th> -->
                    <th>Total Work Time</th>
                    <th>Total Lunch Time</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($entries as $entry): 
                    
                    $first_punch_in = null;
                    $last_punch_out = null;
                    // $log_entries = json_decode($entry->log_entries, true);
                    //$log_entries = is_string($entry->log_entries) ? json_decode($entry->log_entries, true) : [];
                    $log_entries = [];
                        if (is_string($entry->log_entries) && !empty($entry->log_entries)) {
                            $decoded = json_decode($entry->log_entries, true);
                            if (json_last_error() === JSON_ERROR_NONE) {
                                $log_entries = $decoded;
                            }
                        }
                    if (is_array($log_entries)) {
                        // Reverse loop to get actual last punch-in
                        foreach (array_reverse($log_entries) as $log) {
                            if ($log['entry_type'] === 'punch_in') {
                                $first_punch_in = $log['time'];
                                break;
                            }
                        }
                        // Forward loop to get actual first punch-out
                        foreach ($log_entries as $log) {
                            if ($log['entry_type'] === 'punch_out') {
                                $last_punch_out = $log['time'];
                                break;
                            }
                        }
                    }
                    ?>
                <tr id="attendance-row-<?php echo esc_attr($entry->id); ?>">
                    <td><input type="text" class="emp-id employee-id" value="<?php echo esc_html($entry->empid); ?>" readonly>
                    <span class="searchable-text" style="display:none;"><?php echo esc_html($entry->empid); ?></span></td>
                    <td><input type="date" class="log-date" value="<?php echo esc_html($entry->log_date); ?>" readonly>
                    <span class="searchable-date" style="display:none;"><?php echo esc_html($entry->log_date); ?></span></td>
                    <td><input type="text" class="emp-name employee-name" value="<?php echo esc_html($entry->name); ?>" readonly>
                    <span class="searchable-text" style="display:none;"><?php echo esc_html($entry->name); ?></span></td>
                    <!-- <td><textarea class="log-entries" readonly><?php //echo esc_html($entry->log_entries); ?></textarea></td> -->
                    <td><input type="text" class="punch-in" value="<?php echo esc_attr($first_punch_in ?? 'N/A'); ?>" readonly></td>
                    <td><input type="text" class="punch-out" value="<?php echo esc_attr($last_punch_out ?? 'N/A'); ?>" readonly></td>
                    <td><input type="text" class="t-work-time" value="<?php echo esc_html($entry->total_work_time); ?>" readonly></td>
                    <td><input type="text" class="t-lunch-time" value="<?php echo esc_html($entry->total_lunch_time); ?>" readonly></td>                              
                    <td>
                        <button class="view-details-btn" data-attendance-id="<?php echo esc_attr($entry->empid); ?>">View</button>
                        <input type="hidden" class="emp-email" value="<?php echo esc_attr($entry->email); ?>">
                        <input type="hidden" class="emp-depart" value="<?php echo esc_attr($entry->department); ?>">
                        <input type="hidden" class="emp-desig" value="<?php echo esc_attr($entry->designation); ?>">
                        <input type="hidden" class="emp-job_type" value="<?php echo esc_attr($entry->job_type); ?>">
                        <input type="hidden" class="emp-add-date" value="<?php echo esc_attr($entry->created_at); ?>">
                    </td>

                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <div id="AttendanceStatusMessage"></div>   
 <?php
    }
}

?>
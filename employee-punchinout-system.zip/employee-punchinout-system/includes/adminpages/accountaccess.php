<?php 
?>
<div class="wrap">
        <h2>Employee Management - Account access</h2>
        <p>Manage your account access here.</p>
        <form method="POST" class="form_empdata_wrapper">
            <?php wp_nonce_field('eps_management_form', 'eps_management_nonce'); ?>

                <p>
                    <input type="email" name="aemail" id="aemail" placeholder="Enter Email Address" >
                    <input type="text" name="stack_id" id="stack_id" placeholder="Enter Stack Id" >
                </p>
                <p>
                    <input type="text" name="skype_id" id="skype_id" placeholder="Enter Skype ID" >
                    <input type="text" name="github_id" id="github_id" placeholder="Enter GitHub Id" >
                </p>
                
            <input type="submit" name="account_eps_form" id="accountAccessBtn" value="Submit" class="button button-primary">
            <input type="reset" name="account_eps_reset" value="Cancel" class="button button-primary">
        </form>
    </div>
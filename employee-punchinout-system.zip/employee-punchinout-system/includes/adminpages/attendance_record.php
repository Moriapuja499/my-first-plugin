<?php

if(!empty($leaves_summarydata)){

    echo '<h2>Employee Monthly Leave Summary</h2>';
    echo '<table id="leavesSummaryTable">';
    echo '<thead><tr>
        <th>Employee ID</th>
        <th>Name</th>
        <th>Month</th>
        <th>Year</th>
        <th>Allowed Full-Day</th>
        <th>Taken Full-Day</th>
        <th>Carry Forward</th>
        <th>Allowed Short Leaves</th>
        <th>Taken Short Leaves</th>
    </tr></thead><tbody>';

    foreach ($leaves_summarydata as $row) {
        echo '<tr>
            <td>' . esc_html($row->empid) . '</td>
            <td>' . esc_html($row->name) . '</td>
            <td>' . esc_html($row->month) . '</td>
            <td>' . esc_html($row->year) . '</td>
            <td>' . esc_html($row->full_day_allowed) . '</td>
            <td>' . esc_html($row->full_day_taken) . '</td>
            <td>' . esc_html($row->full_day_carry_forward) . '</td>
            <td>' . esc_html($row->short_leave_allowed) . '</td>
            <td>' . esc_html($row->short_leave_taken) . '</td>
        </tr>';
    }

    echo '</tbody></table>';

}
?>
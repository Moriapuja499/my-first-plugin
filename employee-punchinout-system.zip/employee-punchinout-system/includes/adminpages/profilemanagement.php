<?php
  echo '<h1>Profile Management</h1>';
  echo '<p>Manage your profile information here.</p>';
  $current_user = wp_get_current_user();
  $profile_picture = get_user_meta($current_user->ID, 'profile_picture', true);
  $designation = get_user_meta($current_user->ID, 'designation', true);
  $job_type = get_user_meta($current_user->ID, 'job_type', true);
  $designations = get_terms(array('taxonomy' => 'designation', 'hide_empty' => false));
  $job_types = get_terms(array('taxonomy' => 'Job Types', 'hide_empty' => false));

  ?>
  <form method="post" enctype="multipart/form-data">
      <?php wp_nonce_field('eps_update_profile', 'eps_update_profile_nonce'); ?>
      <p>
          <label for="first_name">First Name</label>
          <input type="text" name="first_name" id="first_name" value="<?php echo esc_attr($current_user->first_name); ?>" required>
      </p>
      <p>
          <label for="last_name">Last Name</label>
          <input type="text" name="last_name" id="last_name" value="<?php echo esc_attr($current_user->last_name); ?>" required>
      </p>
      <p>
          <label for="description">Description</label>
          <textarea name="description" id="description" required><?php echo esc_textarea($current_user->description); ?></textarea>
      </p>
      <p>
          <label for="profile_picture">Profile Picture</label>
          <input type="file" name="profile_picture" id="profile_picture">
          <?php if ($profile_picture) : ?>
              <img src="<?php echo esc_url($profile_picture); ?>" alt="Profile Picture" style="max-width: 100px; max-height: 100px;">
          <?php endif; ?>
      </p>
      <p>
          <label for="designation">Designation</label>
          <select name="designation" id="designation" required>
              <?php foreach ($designations as $desig) : ?>
                  <option value="<?php echo esc_attr($desig->slug); ?>" <?php selected($designation, $desig->slug); ?>><?php echo esc_html($desig->name); ?></option>
              <?php endforeach; ?>
          </select>
      </p>
      <p>
          <label for="job_type">Job Type</label>
          <select name="job_type" id="job_type" required>
              <?php foreach ($job_types as $job) : ?>
                  <option value="<?php echo esc_attr($job->slug); ?>" <?php selected($job_type, $job->slug); ?>><?php echo esc_html($job->name); ?></option>
              <?php endforeach; ?>
          </select>
      </p>
      <p>
          <input type="submit" value="Update Profile">
      </p>
  </form>


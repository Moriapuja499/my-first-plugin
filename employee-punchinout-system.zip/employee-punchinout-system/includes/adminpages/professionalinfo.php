<?php
echo '<p>Manage your professional information here.</p>';
    $designations = get_terms(array(
        'taxonomy' => 'designation',
        'hide_empty' => false,
    ));

    $departments = get_terms(array(
        'taxonomy' => 'Departments',
        'hide_empty' => false,
    ));
    $emp_id = wp_rand();
    ?>
    <div class="wrap">
        <h2>Employee Management - Professional Info</h2>
        <form method="POST" class="form_empdata_wrapper">
            <?php wp_nonce_field('eps_management_form', 'eps_management_nonce'); ?>

                <p>
                    <input type="text" name="emp_id" id="emp_id" value="<?php echo $emp_id; ?>" placeholder="Employee ID" >
                    <input type="text" name="user_name" id="user_name" placeholder="User Name">
                </p>
                <p>
            <select name="emp_type" id="emp_type" required>
               <option value="employee type"> Select Employee Type</option>
               <option value="permanent">Permanent</option>
               <option value="temporary">Temporary</option>
            </select>
            <input type="email" name="pemail" id="pemail" placeholder="Email Address" required> 
        </p>
        <p>
        <?php 
            $selected_department = isset($_GET['emp_department']) ? $_GET['emp_department'] : ''; // Get selected department from the form or URL
            ?>
            <select name="emp_department" id="emp_department">
                <option value="Select Department">Select Department</option>
                <?php foreach ($departments as $department) : ?>
                    <option value="<?php echo esc_attr($department->slug); ?>" 
                        <?php selected($selected_department, $department->slug); ?>>
                        <?php echo esc_html($department->name); ?>
                    </option>
                <?php endforeach; ?>
            </select>
           <?php $selected_designation = isset($_GET['emp_designation']) ? $_GET['emp_designation'] : ''; // Get selected department from the form or URL
            ?>
            <select name="emp_designation" id="emp_designation">
                <option value="Select Designation">Select Designation</option>
                <?php foreach ($designations as $desination) : ?>
                    <option value="<?php echo esc_attr($desination->slug); ?>" 
                        <?php selected($selected_designation, $desination->slug); ?>>
                        <?php echo esc_html($desination->name); ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <!-- <input type="text" name="emp_designation" id="emp_designation" placeholder="Enter Designation" required>  -->
        </p>
        <p>
            <select name="working_days" id="working_days">
                <option value="select working days">Select Working Days</option>
                <option value="28">28</option>
                <option value="30">30</option>
                <option value="31">31</option>
            </select>
            <input type="date" name="joining_date" id="joining_date" placeholder="Select Joining Date">
        </p>
        <p>
            <select name="office_loc" id="office_loc" required>
                <option value="Select Office Location">Select Office Location</option>
                <option value="Mohali">Mohali</option>
                <option value="Pune">Pune</option>
            </select>
        </p>
            <input type="submit" name="professional_eps_form" id="professionalInfoBtn" value="Next" class="button button-primary">
            <input type="reset" name="professional_eps_reset" value="Cancel" class="button button-primary">
        </form>
    </div>
<?php
   if (!is_user_logged_in()) {
    return '<p>You need to log in to view your leave applications.</p>';
}

$user_id = get_current_user_id();
global $wpdb;
if ($user_id != 1) {
    return '<p>You do not have permission to view this page.</p>';
}
$table_name = $wpdb->prefix . 'employees';
$table_name2 = $wpdb->prefix . 'eps_leave_applications';
// $entries = $wpdb->get_results(
//         $wpdb->prepare(
//             "SELECT $table_name.ID, $table_name.user_login,$table_name2.id, $table_name2.subject, $table_name2.from_date, $table_name2.to_date, $table_name2.reason, $table_name2.date_applied, $table_name2.status
//             FROM $table_name
//             LEFT JOIN $table_name2 ON $table_name.ID = $table_name2.user_id
//             WHERE $table_name.ID != %d
//             ORDER BY $table_name.user_login;",
//             1 // safely escape and bind the parameter
//         )
//     );
$entries = $wpdb->get_results(
    $wpdb->prepare(
        "SELECT $table_name.empid, $table_name.name, $table_name2.leave_id, $table_name2.subject, $table_name2.from_date, $table_name2.to_date, $table_name2.reason, $table_name2.leave_type, $table_name2.half_day_type, $table_name2.short_leave_time, $table_name2.date_applied, $table_name2.status
        FROM $table_name
        LEFT JOIN $table_name2 ON $table_name.empid = $table_name2.user_id
        WHERE $table_name.empid != %d
        ORDER BY FIELD($table_name2.status, 'approved') DESC, $table_name2.date_applied DESC;",
        1 // safely escape and bind the parameter
    )
);
    if ($entries) {
        ob_start(); ?>
    <h2>List Of Leaves applied by employees</h2>
    <div id="adminViewleaveTable_wrapper">
    <label for="filterYear">Year:</label>
            <select id="filterYear">
                <option value="">All Years</option>
            </select>

            <label for="filterMonth">Month:</label>
            <select id="filterMonth">
                <option value="">All Months</option>
            </select>
            <label for="filterEmployee">Employee Name or ID:</label>
            <input type="text" id="filterEmployee" placeholder="Search by Employee Name or ID">
            <button id="resetFilters">Reset Filters</button>
            
    <table id="adminViewleaveTable" class="display">

            <thead>
                <tr>
                    <th>Employee Id</th>
                    <th>From Date</th>
                    <th>To Date</th>
                    
                    <th>Employee Name</th>
                    <th>Subject</th>
                    
                    <th>Reason</th>
                    <th>Leave Type</th>
                    <th>HalfDay Type</th>
                    <th>ShortLeave Time</th>
                    <th>Date Applied</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($entries as $entry): ?>
                <tr id="leave-row-<?php echo esc_attr($entry->leave_id); ?>">
                    <td><input type="text" class="employee-id" value="<?php echo esc_html($entry->empid); ?>" readonly>
                    <span class="searchable-text" style="display:none;"><?php echo esc_html($entry->empid); ?></span>
                </td>
                    <td><input type="date" class="from-date " value="<?php echo esc_html($entry->from_date); ?>" readonly>
                    <span class="searchable-date" style="display:none;"><?php echo esc_html($entry->from_date); ?></span></td>
                    <td><input type="date" class="to-date " value="<?php echo esc_html($entry->to_date); ?>" readonly>
                    <span class="searchable-date" style="display:none;"><?php echo esc_html($entry->to_date); ?></span></td>
                   
                    <td><input type="text" class="user-login employee-name" value="<?php echo esc_html($entry->name); ?>" readonly>
                    <span class="searchable-text" style="display:none;"><?php echo esc_html($entry->name); ?></span></td>
                    <td><input type="text" class="subject" value="<?php echo esc_html($entry->subject); ?>" readonly></td>
                    
                    <td><textarea class="reason" readonly><?php echo esc_html($entry->reason); ?></textarea></td>
                    <td><input type="text" class="leave-type" value="<?php echo esc_html($entry->leave_type); ?>" readonly></td>
                    <td><input type="text" class="halfday-type" value="<?php echo esc_html($entry->half_day_type); ?>" readonly></td>
                    <td><input type="text" class="shortleave-time" value="<?php echo esc_html($entry->short_leave_time); ?>" readonly></td>
                    <td><input type="datetime-local" class="date-applied" value="<?php echo esc_html($entry->date_applied); ?>" readonly></td>
                    <td> 
                    <select class="status-select">
                                <option value="pending" <?php selected($entry->status, 'pending'); ?>>Pending</option>
                                <option value="approved" <?php selected($entry->status, 'approved'); ?>>Approved</option>
                                <option value="not-approved" <?php selected($entry->status, 'not-approved'); ?>>Not Approved</option>
                            </select>
                    </td>
                    <td>
                        <button class="update-leave-status-btn" data-leave-id="<?php echo esc_attr($entry->leave_id); ?>">Update</button>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
                </div>
        <div id="leaveStatusMessage"></div>   
        <?php
    //     return ob_get_clean();
    // } else {
    //     return '<p>No leave applications found.</p>';
    }
//  $table_html = ob_get_clean();
// } else {
//  $table_html = '<p>You have no status update.</p>';
// }
//echo do_shortcode('[employee_punchinout_system]');
//}






?>
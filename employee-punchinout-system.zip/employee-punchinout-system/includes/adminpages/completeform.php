<?php 
?>
 <div class="wrap">
        <h2>Employee Management - Complete Form</h2>
        <p>check your complete form data here.</p>
        <form method="POST" class="form_empdata_wrapper" name="finalFormSubmits" id="finalFormSubmits">
            <?php wp_nonce_field('eps_management_form', 'eps_management_nonce'); ?>
            <h3>Peronal Info Data</h3>
                <p>
                    <label for="fnemp_id">Employee Id</label>
                    <input type="text" name="fnemp_id" id="fnemp_id">
                </p>

                <p>
                    <label for="fnfirst_name">First Name</label>
                    <input type="text" name="fnfirst_name" id="fnfirst_name" required>
                    <label for="fnlast_name">Last Name</label>
                    <input type="text" name="fnlast_name" id="fnlast_name" required>
                </p>
               <p>
                    <label for="fnmobile">Mobile Number</label>
                    <input type="text" name="fnmobile" id="fnmobile" required>
                    <label for="fnemail">Email Address</label>
                    <input type="email" name="fnemail" id="fnemail" required>
                </p>
                <p>
                    <label for="fndob">Date of Birth</label>
                    <input type="date" name="fndob" id="fndob" required>
                    <label for="fnmarital_status">Marital Status</label>
                    <input type="text" name="fnmarital_status" id="fnmarital_status" required>
                </p>
                <p>
                    <label for="fngender">Gender</label>
                    <input type="text" name="fngender" id="fngender" required>
                    <label for="fnnationality">Nationality</label>
                    <input type="text" name="fnnationality" id="fnnationality" required>
                </p>
                <p>
                <label for="fnaddress">Address</label>
                <textarea name="fnaddress" rows="5" cols="100" id="fnaddress"> </textarea>
                </p>
                <p>
                    <label for="fncity">City</label>
                    <input type="text" name="fncity" id="fncity" required>
                    <label for="fnstate">state</label>
                    <input type="text" name="fnstate" id="fnstate" required>
                    <label for="fnzipcode" >Zip code</label>
                    <input type="text" name="fnzipcode" id="fnzipcode" required>
                </p>
                <h3>Professional Info Data</h3>
                <p>
                    <input type="text" name="fnemp_id2" id="fnemp_id2" placeholder="Employee ID" >
                    <input type="text" name="fnuser_name" id="fnuser_name" placeholder="User Name">
                </p>
                <p>
                <input type="text" name="fnemp_type" id="fnemp_type" placeholder="Employee ID" >
                <input type="email" name="fnpemail" id="fnpemail" placeholder="Email Address" > 
        </p>
        <p>
            <input type="text" name="fnemp_department" id="fnemp_department" placeholder="Select Department" >
            <input type="text" name="fnemp_designation" id="fnemp_designation" placeholder="Enter Designation" > 
        </p>
        <p>
            <input type="text" name="fnworking_days" id="fnworking_days" placeholder="Enter Working Days" > 
            <input type="date" name="fnjoining_date" id="fnjoining_date" placeholder="Select Joining Date">
        </p>
        <p>
        <input type="text" name="fnoffice_loc" id="fnoffice_loc" placeholder="Enter Office Location" > 
        </p>
       
        <h3>Account access Info Data</h3>
        <p>
                    <input type="email" name="fnaemail" id="fnaemail" placeholder="Enter Email Address" >
                    <input type="text" name="fnstack_id" id="fnstack_id" placeholder="Enter Stack Id" >
                </p>
                <p>
                    <input type="text" name="fnskype_id" id="fnskype_id" placeholder="Enter Skype ID" >
                    <input type="text" name="fngithub_id" id="fngithub_id" placeholder="Enter GitHub Id" >
                </p>
                
            <input type="submit" name="final_eps_form" id="finalSubmitsBtn" value="Submit" class="button button-primary">
            <input type="reset" name="final_eps_reset" value="Cancel" class="button button-primary">
        </form>
    </div>
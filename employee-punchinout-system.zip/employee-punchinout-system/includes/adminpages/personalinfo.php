<?php
if (!defined('ABSPATH')) exit;

global $wpdb;

// Step control
$current_step = $_SESSION['current_step'] ?? 1;

// Fetch employee data (for dropdown)
$table_name = $wpdb->prefix . 'eps_employees_data';
$emp_id = $_POST['employee_id'] ?? '';
$emp_data = !empty($emp_id) ? $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE emp_id = %d", $emp_id)) : null;

// Extract previous session or DB data
$personalinfo_data = isset($_SESSION['personal_info']) ? $_SESSION['personal_info'] : json_decode($emp_data->personal_info ?? '{}', true);
$professionalinfo_data = isset($_SESSION['professional_info']) ? $_SESSION['professional_info'] : json_decode($emp_data->professional_info ?? '{}', true);
$accountinfo_data = isset($_SESSION['account_access']) ? $_SESSION['account_access'] : json_decode($emp_data->account_access ?? '{}', true);
?>

<div class="wrap">
    <h2>Employee Management - Personal Information</h2>
    <form method="POST" enctype="multipart/form-data">
        <?php wp_nonce_field('eps_management_form', 'eps_management_nonce'); ?>

        <!-- Selected Employee Id -->
        <?php $empid = isset($_GET['empid']) ? intval($_GET['empid']) : 0;?>
        <p><label for="employee_id">Employee Id:</label>
            <input type="text" name="employee_id" id="employee_id" value="<?php echo $empid; ?>" required>        
        </p>
      

        <?php if ($current_step == 1) : ?>
            <h3>Step 1: Personal Information</h3>
            <p>
                <input type="text" name="first_name" placeholder="First Name" value="<?php echo esc_attr($personalinfo_data['first_name'] ?? ''); ?>" required>
                <input type="text" name="last_name" placeholder="Last Name" value="<?php echo esc_attr($personalinfo_data['last_name'] ?? ''); ?>" required>
            </p>
            <p>
                <input type="text" name="mobile" placeholder="Mobile" value="<?php echo esc_attr($personalinfo_data['mobile'] ?? ''); ?>" required>
                <input type="email" name="email" placeholder="Email" value="<?php echo esc_attr($personalinfo_data['email'] ?? ''); ?>" required>
            </p>
            <p>
                <label for="profile_picture">Profile Picture</label><br>
                <?php if (!empty($personalinfo_data['profile_picture'])): ?>
                    <img src="<?php echo esc_url($personalinfo_data['profile_picture']); ?>" style="width:100px;height:100px;"><br>
                    <input type="file" name="profile_picture">
                    <input type="hidden" name="existing_profile_picture" value="<?php echo esc_attr($personalinfo_data['profile_picture']); ?>">
                <?php else: ?>
                    <input type="file" name="profile_picture">
                <?php endif; ?>
            </p>
            <p>
                <input type="date" name="dob" value="<?php echo esc_attr($personalinfo_data['dob'] ?? ''); ?>" required>
                <select name="marital_status">
                    <option value="">Marital Status</option>
                    <option value="single" <?php selected($personalinfo_data['marital_status'] ?? '', 'single'); ?>>Single</option>
                    <option value="married" <?php selected($personalinfo_data['marital_status'] ?? '', 'married'); ?>>Married</option>
                    <option value="separated" <?php selected($personalinfo_data['marital_status'] ?? '', 'separated'); ?>>Separated</option>
                </select>
            </p>
            <p>
                <label>Gender</label><br>
                <input type="radio" name="gender" value="male" <?php checked($personalinfo_data['gender'] ?? '', 'male'); ?>> Male
                <input type="radio" name="gender" value="female" <?php checked($personalinfo_data['gender'] ?? '', 'female'); ?>> Female
            </p>
            <p>
                <input type="text" name="nationality" placeholder="Nationality" value="<?php echo esc_attr($personalinfo_data['nationality'] ?? ''); ?>" required>
            </p>
            <p>
                <textarea name="address" rows="3" placeholder="Address"><?php echo esc_textarea($personalinfo_data['address'] ?? ''); ?></textarea>
            </p>
            <p>
                <input type="text" name="city" placeholder="City" value="<?php echo esc_attr($personalinfo_data['city'] ?? ''); ?>" required>
                <input type="text" name="state" placeholder="State" value="<?php echo esc_attr($personalinfo_data['state'] ?? ''); ?>" required>
                <input type="text" name="zipcode" placeholder="Zip Code" value="<?php echo esc_attr($personalinfo_data['zipcode'] ?? ''); ?>" required>
            </p>
            <input type="hidden" name="current_step" value="1">
            <button type="submit" name="step1_next" class="button button-primary">Next</button>
            <input type="submit" name="personal_eps_reset" value="Cancel" class="button">
        <?php elseif ($current_step == 2) : ?>
            <h3>Step 2: Professional Information</h3>
            <p>
                <input type="text" name="experience" placeholder="Experience" value="<?php echo esc_attr($professionalinfo_data['experience'] ?? ''); ?>">
                <input type="text" name="certification" placeholder="Certification" value="<?php echo esc_attr($professionalinfo_data['certification'] ?? ''); ?>">
            </p>
            <input type="hidden" name="current_step" value="2">
            <button type="submit" name="step2_next" class="button button-primary">Next</button>
        <?php elseif ($current_step == 3) : ?>
            <h3>Step 3: Account Access Details</h3>
            <p>
                <input type="text" name="slackid" placeholder="Slack ID" value="<?php echo esc_attr($accountinfo_data['slackid'] ?? ''); ?>">
                <input type="text" name="skypeid" placeholder="Skype ID" value="<?php echo esc_attr($accountinfo_data['skypeid'] ?? ''); ?>">
                <input type="text" name="githubid" placeholder="GitHub ID" value="<?php echo esc_attr($accountinfo_data['githubid'] ?? ''); ?>">
            </p>
            <input type="hidden" name="current_step" value="3">
            <button type="submit" name="step3_next" class="button button-primary">Next</button>
            <?php  elseif ($current_step == 4) : ?>
    <h3>Step 4: Review & Submit</h3>
        <h2>Personal Info</h2>
            <?php if (isset($_SESSION['personal_info']) && is_array($_SESSION['personal_info'])): ?>
                <table>
                    <thead><tr><th>Field</th><th>Value</th></tr></thead>
                    <tbody>
                        <?php foreach ($_SESSION['personal_info'] as $key => $value): ?>
                            <tr>
                                <?php if($key == 'profile_picture') { ?>
                                    <td><?php echo esc_html($key); ?></td>
                                <td><img src="<?php echo esc_html($value); ?>" alt="profileimg"></td>
                                    <?php } else { ?>
                                <td><?php echo esc_html($key); ?></td>
                                <td><?php echo esc_html($value); ?></td>
                                <?php  } ?>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        <hr>
        <h2>Professional Info</h2>
            <?php if (isset($_SESSION['professional_info']) && is_array($_SESSION['professional_info'])): ?>
                <table>
                    <thead><tr><th>Field</th><th>Value</th></tr></thead>
                    <tbody>
                        <?php foreach ($_SESSION['professional_info'] as $key => $value): ?>
                            <tr>
                                <td><?php echo esc_html($key); ?></td>
                                <td><?php echo esc_html($value); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        <hr>
        <h2>Account Access</h2>
            <?php if (isset($_SESSION['account_access']) && is_array($_SESSION['account_access'])): ?>
                <table>
                    <thead><tr><th>Field</th><th>Value</th></tr></thead>
                    <tbody>
                        <?php foreach ($_SESSION['account_access'] as $key => $value): ?>
                            <tr>
                                <td><?php echo esc_html($key); ?></td>
                                <td><?php echo esc_html($value); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        <hr>
    
 
        
    
   
    <!-- <pre>
        <?php
        // Check if session data exists before trying to access it
        //echo isset($_SESSION['personal_info']) ? esc_html(print_r($_SESSION['personal_info'], true)) : 'No personal information found.';
        ?>
    </pre> -->
    <!-- <pre>
        <?php
        // Check if session data exists before trying to access it
       // echo isset($_SESSION['professional_info']) ? esc_html(print_r($_SESSION['professional_info'], true)) : 'No professional information found.';
        ?>
    </pre>
    <pre>
        <?php
        // Check if session data exists before trying to access it
        //echo isset($_SESSION['account_access']) ? esc_html(print_r($_SESSION['account_access'], true)) : 'No account access information found.';
        ?>
    </pre> -->
    <?php wp_nonce_field('eps_profile_step4_action', 'eps_employee_details_nonce'); ?>
    <input type="hidden" name="current_step" value="4">
    <button type="submit" name="final_submit" class="button button-primary">Submit All</button>
<?php endif; ?>
    </form>
</div>

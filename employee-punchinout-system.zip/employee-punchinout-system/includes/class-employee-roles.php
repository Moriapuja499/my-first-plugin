<?php

class Employee_Roles {
    public static function add_roles() {
        add_role( 'employee_manager', __( 'Employee Manager', 'employee-punchinout-system' ), [
            'read'             => true,
            'edit_employees'   => true,
            'delete_employees' => true,
        ] );
    }

    public static function add_capabilities() {
        $roles = [ 'administrator', 'employee_manager' ];

        foreach ( $roles as $role_name ) {
            $role = get_role( $role_name );

            if ( $role ) {
                $role->add_cap( 'edit_employee' );
                $role->add_cap( 'read_employee' );
                $role->add_cap( 'delete_employee' );
            }
        }
    }

    public static function remove_roles() {
        remove_role( 'employee_manager' );
    }
}
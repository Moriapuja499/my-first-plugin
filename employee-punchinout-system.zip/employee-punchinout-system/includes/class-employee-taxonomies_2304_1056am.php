<?php

class Employee_Taxonomies {
    public static function init() {
        add_action( 'init', [ __CLASS__, 'register_taxonomies' ] );
    }

    public static function register_taxonomies() {
        // Register Department Taxonomy
        register_taxonomy( 'department', 'employee', [
            'labels' => [
                'name'          => __( 'Departments', 'employee-punchinout-system' ),
                'singular_name' => __( 'Department', 'employee-punchinout-system' ),
                'menu_name'     => __( 'Department', 'employee-punchinout-system' ),
            ],
            'public'            => false,
            'hierarchical'      => true,
            'show_ui'           => true,
            'show_admin_column' => true,
        ]);

        // Register Designation Taxonomy
        register_taxonomy( 'designation', 'employee', [
            'labels' => [
                'name'          => __( 'Designations', 'employee-punchinout-system' ),
                'singular_name' => __( 'Designation', 'employee-punchinout-system' ),
                'menu_name'     => __( 'Designation', 'employee-punchinout-system' ),
            ],
            'public'            => false,
            'hierarchical'      => true,
            'show_ui'           => true,
            'show_admin_column' => true,
        ]);

        // Register Job Type Taxonomy
        register_taxonomy( 'job_type', 'employee', [
            'labels' => [
                'name'          => __( 'Job Types', 'employee-punchinout-system' ),
                'singular_name' => __( 'Job Type', 'employee-punchinout-system' ),
                'menu_name'     => __( 'Job Type', 'employee-punchinout-system' ),
            ],
            'public'            => false,
            'hierarchical'      => true,
            'show_ui'           => true,
            'show_admin_column' => true,
        ]);
    }
}

Employee_Taxonomies::init();
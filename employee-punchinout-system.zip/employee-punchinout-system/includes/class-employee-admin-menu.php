<?php

class Employee_Admin_Menu {
    public static function init() {
        add_action( 'admin_menu', [ __CLASS__, 'add_admin_menu' ] );
    }

    public static function add_admin_menu() {
        // Single top-level "Employees" menu
        add_menu_page(
            __( 'Employees', 'employee-punchinout-system' ),
            __( 'Employees', 'employee-punchinout-system' ),
            'manage_options',
            'employee-punchinout-system',
            [ __CLASS__, 'render_employee_list' ],
            'dashicons-id',
            25
        );

        // Submenu: All Employees
        add_submenu_page(
            'employee-punchinout-system',
            __( 'All Employees', 'employee-punchinout-system' ),
            __( 'All Employees', 'employee-punchinout-system' ),
            'manage_options',
            'employee-punchinout-system',
            [ __CLASS__, 'render_employee_list' ]
        );

        // Submenu: Add New Employee
        add_submenu_page(
            'employee-punchinout-system',
            __( 'Add New Employee', 'employee-punchinout-system' ),
            __( 'Add New Employee', 'employee-punchinout-system' ),
            'manage_options',
            'add-employee',
            [ __CLASS__, 'render_add_employee' ]
        );

        // Submenu: Department
        add_submenu_page(
            'employee-punchinout-system',
            __( 'Departments', 'employee-punchinout-system' ),
            __( 'Departments', 'employee-punchinout-system' ),
            'manage_options',
            'employee_departments',
            [ __CLASS__, 'redirect_to_department' ]
        );
        
        //submenu designation
        add_submenu_page(
            'employee-punchinout-system',
            __( 'Designations', 'employee-punchinout-system' ),
            __( 'Designations', 'employee-punchinout-system' ),
            'manage_options',
            'employee_designations',
            [ __CLASS__, 'redirect_to_designation' ]
        );
        
           //submenu job types
        add_submenu_page(
            'employee-punchinout-system',
            __( 'Job Types', 'employee-punchinout-system' ),
            __( 'Job Types', 'employee-punchinout-system' ),
            'manage_options',
            'employee_job_types',
            [ __CLASS__, 'redirect_to_job_type' ]
        );
        
        // Submenu: Leave Info
        add_submenu_page(
            'employee-punchinout-system',
            __( 'Leave Info', 'employee-punchinout-system' ),
            __( 'Leave Info', 'employee-punchinout-system' ),
            'manage_options',
            'eps_leave_info',
            'eps_leave_info_page'
        );

        // Submenu: Attendance Info
        add_submenu_page(
            'employee-punchinout-system',
            __( 'Attendance Info', 'employee-punchinout-system' ),
            __( 'Attendance Info', 'employee-punchinout-system' ),
            'manage_options',
            'eps_attendance_info',
            'eps_attendance_info_page'
        );

        // Submenu: Attendance Record
        add_submenu_page(
            'employee-punchinout-system',
            __( 'Attendance Record', 'employee-punchinout-system' ),
            __( 'Attendance Record', 'employee-punchinout-system' ),
            'manage_options',
            'eps_attendance_record',
            'eps_attendance_record_page'
        );
    }


    public static function redirect_to_department() {
        if ( ! headers_sent() ) {
            wp_redirect( admin_url( 'edit-tags.php?taxonomy=department&post_type=employee' ) );
            exit;
        } else {
            echo '<script>window.location.href="' . admin_url( 'edit-tags.php?taxonomy=department&post_type=employee' ) . '";</script>';
            exit;
        }
    }
    public static function redirect_to_designation() {
        if ( ! headers_sent() ) {
            wp_redirect( admin_url( 'edit-tags.php?taxonomy=designation&post_type=employee' ) );
            exit;
        } else {
            echo '<script>window.location.href="' . admin_url( 'edit-tags.php?taxonomy=designation&post_type=employee' ) . '";</script>';
            exit;
        }
    }
    public static function redirect_to_job_type() {
        if ( ! headers_sent() ) {
            wp_redirect( admin_url( 'edit-tags.php?taxonomy=job_type&post_type=employee' ) );
            exit;
        } else {
            echo '<script>window.location.href="' . admin_url( 'edit-tags.php?taxonomy=job_type&post_type=employee' ) . '";</script>';
            exit;
        }
    }
    public static function save_employee_data() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'employees';
    
        // Verify nonce
        if (!isset($_POST['employee_nonce']) || !wp_verify_nonce($_POST['employee_nonce'], 'save_employee')) {
            wp_die(__('Nonce verification failed', 'employee-punchinout-system'));
        }
    
        // Determine the action type: add, update, delete
        $action_type = isset($_POST['action_type']) ? sanitize_text_field($_POST['action_type']) : 'add';
        $manual_empid = sanitize_text_field($_POST['employee_id']);
    
        // DELETE operation
        if ($action_type === 'delete') {
            if (empty($manual_empid)) {
                echo '<div class="error"><p>' . __('Employee ID is required to delete.', 'employee-punchinout-system') . '</p></div>';
                return;
            }
    
            $deleted = $wpdb->delete($table_name, ['empid' => $manual_empid]);
    
            if ($deleted) {
                 '<div class="updated"><p>' . __('Employee deleted successfully.', 'employee-punchinout-system') . '</p></div>';
                //wp_redirect(admin_url('admin.php?page=employee-list&deleted=1'));
                   // exit;
                
            } else {
                echo '<div class="error"><p>' . __('Failed to delete employee or employee not found.', 'employee-punchinout-system') . '</p></div>';
            }
            return;
        }
    
        // Common fields for ADD and UPDATE
        $employee_name        = sanitize_text_field($_POST['employee_name']);
        $employee_email       = sanitize_email($_POST['employee_email']);
        $employee_department  = sanitize_text_field($_POST['employee_department']);
        $employee_designation = sanitize_text_field($_POST['employee_designation']);
        $employee_job_type    = sanitize_text_field($_POST['employee_job_type']);
        $password_option      = sanitize_text_field($_POST['employee_password_option']);
    
        $depart = get_term($employee_department);
        $department_name = !is_wp_error($depart) ? $depart->description : $employee_department;
    
        $designation = get_term($employee_designation);
        $designation_name = !is_wp_error($designation) ? $designation->description : $employee_designation;
    
        $job_type = get_term($employee_job_type);
        $job_name = !is_wp_error($job_type) ? $job_type->description : $employee_job_type;
    
        // Handle Password
        if ($password_option === 'custom') {
            $employee_password = sanitize_text_field($_POST['employee_password']);
            if (empty($employee_password)) {
                echo '<div class="error"><p>' . __('Custom password cannot be empty.', 'employee-punchinout-system') . '</p></div>';
                return;
            }
        } else {
            $employee_password = wp_generate_password(12, false);
        }
    // Check if empid already exists → switch to update if so
    if (!empty($manual_empid)) {
        $employee_exists = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table_name WHERE empid = %s", $manual_empid));
        if ($employee_exists > 0 && $action_type !== 'update') {
            // Change to update mode
            $action_type = 'update';
        }
    }

    // UPDATE operation
    if ($action_type === 'update') {
        if (empty($manual_empid)) {
            echo '<div class="error"><p>' . __('Employee ID is required to update.', 'employee-punchinout-system') . '</p></div>';
            return;
        }

        $update_data = [
            'name'        => $employee_name,
            'email'       => $employee_email,
            'department'  => $department_name,
            'designation' => $designation_name,
            'job_type'    => $job_name,
        ];

        if (!empty($employee_password) || $password_option === 'generate') {
            $update_data['password'] = wp_hash_password($employee_password);
        }

        $updated = $wpdb->update($table_name, $update_data, ['empid' => $manual_empid]);

        if ($updated !== false) {
            echo '<div class="updated"><p>' . __('Employee updated successfully.', 'employee-punchinout-system') . '</p></div>';
            // wp_redirect(admin_url('admin.php?page=employee-list&updated=1'));
            // exit;
        } else {
            echo '<div class="error"><p>' . __('Failed to update employee.', 'employee-punchinout-system') . '</p></div>';
        }
        return;
    }
 // ADD operation
 if (empty($manual_empid)) {
    // Get highest numeric empid only
    $max_empid = $wpdb->get_var("SELECT MAX(CAST(empid AS UNSIGNED)) FROM $table_name WHERE empid REGEXP '^[0-9]+$'");
    $next_empid = str_pad(((int)$max_empid + 1), 3, '0', STR_PAD_LEFT);
    $employee_id = $next_empid;
} else {
    $employee_id = $manual_empid;
    $exists = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table_name WHERE empid = %s", $employee_id));
    if ($exists > 0) {
        echo '<div class="error"><p>' . __('Employee ID already exists. Please use a different ID or leave blank to auto-generate.', 'employee-punchinout-system') . '</p></div>';
        return;
    }
}
        
    
        $inserted = $wpdb->insert(
            $table_name,
            [
                'empid'      => $employee_id,
                'name'       => $employee_name,
                'email'      => $employee_email,
                'department' => $department_name,
                'designation'=> $designation_name,
                'job_type'   => $job_name,
                'password'   => wp_hash_password($employee_password),
                'created_at' => current_time('mysql'),
            ]
        );
    
        if ($inserted) {

            $subject = __('Welcome to the Global Studioz Company!', 'employee-punchinout-system');

$message = "
<table cellpadding='0' cellspacing='0' border='0' style='font-family:arial; font-size:15px;' width='100%'>
<tr>
    <td align='center' style='padding:20px; background:#ffffff;'>
        <table cellpadding='0' cellspacing='0' border='0' style='font-family:arial; font-size:15px;' width='500' align='center'>
            <tr>
                <td align='center' colspan='2'>
                    <img width='250' src='https://globalstudioz.com/images/svg/logo-small.svg' alt='Company Logo' />
                </td>
            </tr>
            <tr><td height='30'></td></tr>
            <tr>
                <td colspan='2'>
                    <h3 style='font-size:22px;'>Dear {$employee_name},</h3>
                    <p style='font-size:18px;'>Welcome to Global Studioz! Below are your onboarding details:</p>
                </td>
            </tr>
            <tr><td height='30'></td></tr>
            <tr><td colspan='2' bgcolor='#0073aa' style='padding:10px 20px; color:#ffffff;'><h3 style='margin:0; text-transform:uppercase;'>Employee Details</h3></td></tr>
            <tr>
                <td style='padding:10px; font-weight:bold;'>Employee ID:</td>
                <td style='padding:10px;'>{$employee_id}</td>
            </tr>
            <tr>
                <td style='padding:10px; font-weight:bold;'>Email:</td>
                <td style='padding:10px;'><a href='mailto:{$employee_email}'>{$employee_email}</a></td>
            </tr>
            <tr>
                <td style='padding:10px; font-weight:bold;'>Password:</td>
                <td style='padding:10px;'>{$employee_password}</td>
            </tr>
            <tr>
                <td style='padding:10px; font-weight:bold;'>Department:</td>
                <td style='padding:10px;'>{$department_name}</td>
            </tr>
            <tr>
                <td style='padding:10px; font-weight:bold;'>Designation:</td>
                <td style='padding:10px;'>{$designation_name}</td>
            </tr>
            <tr>
                <td style='padding:10px; font-weight:bold;'>Job Type:</td>
                <td style='padding:10px;'>{$job_name}</td>
            </tr>
            <tr><td height='30'></td></tr>
            <tr>
                <td colspan='2' align='center'>
                    <p style='font-size:14px; line-height:1.5;'>Login Here <a href='https://up-lyf.com/code/phrm' target='_blank'>https://up-lyf.com/code/phrm</a> <br><br>We’re excited to have you on the team! Let’s achieve great things together.</p>
                    <p style='font-size:14px; line-height:1.5;'>Regards,<br><strong>Global Studioz</strong><br>3rd Floor Mirans Square, Plot No. D-180C<br>Phase 8B Industrial Area, Sector 74<br>Sahibzada Ajit Singh Nagar, Punjab 160055<br>Phone: 097800 88824</p>
                </td>
            </tr>
        </table>
    </td>
</tr>
</table>
";

// Send as HTML
$headers = ['Content-Type: text/html; charset=UTF-8'];

wp_mail($employee_email, $subject, $message, $headers);

//             wp_mail(
//                 $employee_email,
//                 __('Welcome to the Company!', 'employee-punchinout-system'),
//                 sprintf(
//                     __("Hi %s,\n\nWelcome to the Global Studioz company!\n\nEmployeeId: %s\nEmail: %s\nPassword: %s\nDepartment: %s\nDesignation: %s\nJob Type: %s\n\nRegards,\n Global Studioz \n 3rd Floor Mirans Square Plot no. D-180C \n Phase 8B Industrial Area \n Sector 74 Sahibzada Ajit Singh Nagar\n Punjab 160055
// \nPhone: 097800 88824", 'employee-punchinout-system'),
                    
//                     $employee_name,
//                     $manual_empid,
//                     $employee_email,
//                     $employee_password,
//                     $department_name,
//                     $designation_name,
//                     $job_name
//                 ),
//                 ['Content-Type: text/plain; charset=UTF-8']
//             );
    
            echo '<div class="updated"><p>' . __('Employee added successfully and email sent.', 'employee-punchinout-system') . '</p></div>';
        } else {
            echo '<div class="error"><p>' . __('Failed to add employee. Please try again.', 'employee-punchinout-system') . '</p></div>';
        }
    }
    

    public static function render_employee_list() {
        echo '<h1>' . __( 'Employee List', 'employee-punchinout-system' ) . '</h1>';
        include plugin_dir_path( __FILE__ ) . 'adminpages/all-employees-list.php';
        // Display employee table here
    }

    public static function render_add_employee() {
        include plugin_dir_path( __FILE__ ) . 'adminpages/add-employee-form.php';
    }

}

Employee_Admin_Menu::init();
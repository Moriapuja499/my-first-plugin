<?php
if (!defined('ABSPATH')) {
    exit;
}

// Shared scripts/styles for both frontend and admin
function eps_enqueue_common_assets() {
    wp_enqueue_style('eps-style', EPS_PLUGIN_URL . 'assets/css/style.css', [], filemtime(EPS_PLUGIN_DIR . 'assets/css/style.css'));
    wp_enqueue_style('eps-animate', EPS_PLUGIN_URL . 'assets/css/animate.css');
    wp_enqueue_style('eps-responsive', EPS_PLUGIN_URL . 'assets/css/responsive.css');
    wp_enqueue_style('eps-design', EPS_PLUGIN_URL . 'assets/css/design.css');

    // DataTables core and extensions
    wp_enqueue_style('datatables-css', 'https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css');
    wp_enqueue_style('datatables-buttons-css', 'https://cdn.datatables.net/buttons/2.4.1/css/buttons.dataTables.min.css');
    wp_enqueue_script('datatables-js', 'https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js', ['jquery'], null, true);
    wp_enqueue_script('datatables-buttons-js', 'https://cdn.datatables.net/buttons/2.4.1/js/dataTables.buttons.min.js', ['jquery'], null, true);
    wp_enqueue_script('jszip', 'https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js', ['jquery'], null, true);
    wp_enqueue_script('pdfmake', 'https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js', ['jquery'], null, true);
    wp_enqueue_script('vfs_fonts', 'https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js', ['jquery'], null, true);
    wp_enqueue_script('buttons-html5', 'https://cdn.datatables.net/buttons/2.4.1/js/buttons.html5.min.js', ['jquery'], null, true);
    wp_enqueue_script('buttons-print', 'https://cdn.datatables.net/buttons/2.4.1/js/buttons.print.min.js', ['jquery'], null, true);

    // Other common assets
    wp_enqueue_script('eps-wow', EPS_PLUGIN_URL . 'assets/js/wow.js', ['jquery'], null, true);
    wp_enqueue_script('eps-tailwind', 'https://cdn.tailwindcss.com', ['jquery'], null, true);
    wp_enqueue_script('eps-clock', 'https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.9.0/moment-with-locales.js', ['jquery'], null, true);
    wp_enqueue_script('eps-clock-moment', 'https://cdnjs.cloudflare.com/ajax/libs/moment-timezone/0.5.4/moment-timezone-with-data.min.js', ['jquery'], null, true);
}
add_action('wp_enqueue_scripts', 'eps_enqueue_common_assets');
add_action('admin_enqueue_scripts', 'eps_enqueue_common_assets');

// Localize and enqueue main plugin scripts
function eps_mainjs_enqueue_scripts() {
    $emp_id = isset($_SESSION['employee_id']) ? $_SESSION['employee_id'] : 'guest';
    $emp_name = isset($_SESSION['employee_name']) ? $_SESSION['employee_name'] : 'Employee';

    wp_enqueue_script('eps-utils', EPS_PLUGIN_URL . 'assets/js/utils.js', ['jquery'], null, true);
    wp_enqueue_script('eps-punchinout', EPS_PLUGIN_URL . 'assets/js/punchinout-system.js', ['jquery', 'eps-utils'], null, true);
    wp_enqueue_script('eps-empleaveswork', EPS_PLUGIN_URL . 'assets/js/empleaveswork.js', ['jquery', 'eps-utils'], null, true);
    wp_enqueue_script('eps-frontcounter', EPS_PLUGIN_URL . 'assets/js/frontcounter.js', ['jquery', 'eps-utils'], null, true);
    wp_enqueue_script('eps-main', EPS_PLUGIN_URL . 'assets/js/main.js', ['jquery', 'eps-punchinout', 'eps-empleaveswork', 'eps-frontcounter' ], null, true);

    wp_localize_script('eps-main', 'eps_ajax', [
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('eps_apply_leave_nonce'),
        'nonce_upleave' => wp_create_nonce('eps_nonce'),
        'nonce_leave' => wp_create_nonce('eps_leave_nonce'),
        'nonce_action' => wp_create_nonce('eps_secure_action'),
        'nonce_management' => wp_create_nonce('eps_management_nonce'),
        'nonce_perform_action' => wp_create_nonce('eps_nonceperform_action'),
        'nonce_update_leave' => wp_create_nonce('eps_update_leave_nonce'),
        'nonce_editemp' => wp_create_nonce('eps_editemp_nonce'),
        'nonce_edit_profile_step4' => wp_create_nonce('eps_edit_profile_step4_action'),
        'employee_id' => $emp_id,
        'employee_name' => $emp_name,
        'plugin_url' => plugin_dir_url(__FILE__),
        'profilePageUrl' => admin_url('admin.php?page=eps_profile_management'),
    ]);

}
add_action('wp_enqueue_scripts', 'eps_mainjs_enqueue_scripts');
add_action('admin_enqueue_scripts', 'eps_mainjs_enqueue_scripts');

// Favicon
function eps_add_favicon() {
    echo '<link rel="icon" type="image/svg+xml" href="' . EPS_PLUGIN_URL . 'images/svg/fav.svg">';
}
add_action('wp_head', 'eps_add_favicon');

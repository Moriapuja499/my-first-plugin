<?php
if (!defined('ABSPATH')) exit;
//Add Employee Data

function save_employee_data() {
    if (!isset($_POST['eps_management_nonce']) || !wp_verify_nonce($_POST['eps_management_nonce'], 'eps_management_form')) {
        echo json_encode(['success' => false, 'error' => 'Nonce verification failed']);
        exit;
    }
  
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        global $wpdb;
        //$emp_id = wp_rand();
        //$table_name = $wpdb->prefix . 'eps_employees';
        $table_name = $wpdb->prefix . 'eps_employees_data';
        // Get Data from AJAX Request
if (isset($_POST['personalInfo']) && isset($_POST['professionalInfo']) && isset($_POST['accountAccessInfo'])) {
    // Decode and sanitize inputs
    $personalInfo = json_decode(stripslashes($_POST['personalInfo']), true);
    $professionalInfo = json_decode(stripslashes($_POST['professionalInfo']), true);
    $accountAccessInfo = json_decode(stripslashes($_POST['accountAccessInfo']), true);

    // Check for missing required fields
    if (empty($personalInfo['first_name']) || empty($personalInfo['last_name'])) {
        echo json_encode(['success' => false, 'error' => 'Missing required personal information.']);
        exit;
    }

    if (empty($professionalInfo['emp_id'])) {
        echo json_encode(['success' => false, 'error' => 'Missing employee ID in professional information.']);
        exit;
    }

    // Sanitize fields
    $personal_info = array(
        'first_name' => sanitize_text_field($personalInfo['first_name']),
        'last_name' => sanitize_text_field($personalInfo['last_name']),
        'mobile' => sanitize_text_field($personalInfo['mobile']),
        'email' => sanitize_email($personalInfo['email']),
        'dob' => sanitize_text_field($personalInfo['dob']),
        'marital_status' => sanitize_text_field($personalInfo['marital_status']),
        'gender' => sanitize_text_field($personalInfo['gender']),
        'nationality' => sanitize_text_field($personalInfo['nationality']),
        'address' => sanitize_textarea_field($personalInfo['address']),
        'city' => sanitize_text_field($personalInfo['city']),
        'state' => sanitize_text_field($personalInfo['state']),
        'zipcode' => sanitize_text_field($personalInfo['zipcode'])
    );

    $professional_info = array(
        'emp_id' => sanitize_text_field($professionalInfo['emp_id']),
        'user_name' => sanitize_text_field($professionalInfo['user_name']),
        'emp_type' => sanitize_text_field($professionalInfo['emp_type']),
        'pemail' => sanitize_email($professionalInfo['pemail']),
        'emp_department' => sanitize_text_field($professionalInfo['emp_department']),
        'emp_designation' => sanitize_text_field($professionalInfo['emp_designation']),
        'working_days' => sanitize_text_field($professionalInfo['working_days']),
        'joining_date' => sanitize_text_field($professionalInfo['joining_date']),
        'office_loc' => sanitize_textarea_field($professionalInfo['office_loc'])
    );

    $account_access_info = array(
        'aemail' => sanitize_email($accountAccessInfo['fnaemail']),
        'stack_id' => sanitize_text_field($accountAccessInfo['fnstack_id']),
        'skype_id' => sanitize_text_field($accountAccessInfo['fnskype_id']),
        'github_id' => sanitize_text_field($accountAccessInfo['fngithub_id']),
    );

    // Combine all information into one array
    $employee_data = array(
        'emp_id' => $emp_id,
        'personal_info' => serialize($personal_info), // Serialize the array for storage
        'professional_info' => serialize($professional_info), // Serialize the array for storage
        'account_access' => serialize($account_access_info), // Serialize the array for storage
    );

    $insert_result = $wpdb->insert($table_name, $employee_data);

    if ($insert_result === false) {
        echo json_encode(['success' => false, 'error' => $wpdb->last_error]); // Output the error
        exit;
    }

    // Send success response
    echo json_encode(['success' => true, 'emp_id' => $emp_id]);
    exit;
} else {
    echo json_encode(['success' => false, 'error' => 'Missing required data in the request']);
    exit;
}

    }

}
add_action('wp_ajax_save_employee_data', 'save_employee_data');

function handle_employee_form_submission() {
    if (isset($_POST['submit_employee']) && isset($_POST['employee_nonce']) && wp_verify_nonce($_POST['employee_nonce'], 'add_employee')) {
        
        // Gather data from the form
        $username = sanitize_text_field($_POST['user_login']);
        $email = sanitize_email($_POST['user_email']);
        $first_name = sanitize_text_field($_POST['first_name']);
        $last_name = sanitize_text_field($_POST['last_name']);
        $employee_department = sanitize_text_field($_POST['employee_department']);
        $employee_id = sanitize_text_field($_POST['employee_id']);
        $generate_password = isset($_POST['generate_password']) ? true : false;

        // Check if the username/email already exists
        if (username_exists($username) || email_exists($email)) {
            echo '<div class="error"><p>' . __('Username or Email already exists.') . '</p></div>';
            return;
        }

        // Create the new user (employee)
        $user_id = wp_create_user($username, '', $email);
        
        if (is_wp_error($user_id)) {
            echo '<div class="error"><p>' . __('Error creating employee.') . '</p></div>';
            return;
        }

        // Update the user with custom fields
        wp_update_user([
            'ID' => $user_id,
            'first_name' => $first_name,
            'last_name' => $last_name,
        ]);

        // Add custom employee meta fields
        update_user_meta($user_id, 'employee_department', $employee_department);
        update_user_meta($user_id, 'employee_id', $employee_id);

        // Generate password if needed
        if ($generate_password) {
            $password = wp_generate_password();
            wp_set_password($password, $user_id);

            // Send login details to employee via email
            $message = sprintf(
                __('Hello %s, you have been added as an employee. Your login details are as follows: \n\nUsername: %s\nPassword: %s\n\nBest regards.', 'employee-dashboard'),
                $first_name,
                $username,
                $password
            );

            $subject = __('Your Employee Login Details', 'employee-dashboard');
            $headers = ['Content-Type: text/plain; charset=UTF-8'];
            
            // Use WordPress' wp_mail function
            $email_sent = wp_mail($email, $subject, $message, $headers);
            if (!$email_sent) {
                error_log('Email failed to send.');
            }
        }

        echo '<div class="updated"><p>' . __('Employee added successfully.') . '</p></div>';
    }
}
add_action('admin_post_add_employee', 'handle_employee_form_submission');

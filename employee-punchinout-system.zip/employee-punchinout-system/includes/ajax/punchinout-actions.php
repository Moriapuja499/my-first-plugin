<?php
if (!defined('ABSPATH')) exit;
add_action('wp_ajax_eps_perform_action', 'eps_perform_action');
add_action('wp_ajax_nopriv_eps_perform_action', 'eps_perform_action');

function eps_perform_action() {
    check_ajax_referer('eps_nonceperform_action');
    if (!isset($_SESSION['employee_id']) || !isset($_SESSION['employee_name'])) {
        wp_send_json_error(['error' => 'Not logged in']);
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'eps_log';

    $user_id = $_SESSION['employee_id'];
    $username = sanitize_file_name($_SESSION['employee_name']);
    $entry_type = sanitize_text_field($_POST['entry_type']);
  
    $time = current_time('mysql');
    $date = current_time('Y-m-d', 1);

    // DB Logging - fetch existing entries before processing
    $existing_entry = $wpdb->get_row(
        $wpdb->prepare("SELECT * FROM $table_name WHERE user_id = %d AND DATE(log_date) = %s LIMIT 1", $user_id, $date)
    );

    $log_entries = $existing_entry ? json_decode($existing_entry->log_entries, true) : [];

    // Validation Before Appending
    if ($entry_type === 'lunch_out') {
        foreach ($log_entries as $entry) {
            if ($entry['entry_type'] === 'lunch_out') {
                wp_send_json_error(['error' => 'Lunch already started.']);
            }
        }
    }

    if ($entry_type === 'lunch_in') {
        $lunch_out_time = null;
        foreach ($log_entries as $entry) {
            if ($entry['entry_type'] === 'lunch_in') {
                wp_send_json_error(['error' => 'Lunch already completed.']);
            }
            if ($entry['entry_type'] === 'lunch_out') {
                $lunch_out_time = strtotime($entry['time']);
            }
        }
        if (!$lunch_out_time) {
            wp_send_json_error(['error' => 'Lunch out not done yet.']);
        }
        $lunch_in_time = strtotime($time);
        $total_lunch_seconds = $lunch_in_time - $lunch_out_time;
    }

    // Append new entry only after validation
    $log_entry = [
        'entry_type' => $entry_type,
        'time' => $time
    ];
    $log_entries[] = $log_entry;

    // Work time calculation
    $total_work_seconds = 0;
    if ($entry_type === 'punch_out') {
        $punch_stack = [];
        foreach ($log_entries as $entry) {
            if ($entry['entry_type'] === 'punch_in') {
                $punch_stack[] = strtotime($entry['time']);
            }
            if ($entry['entry_type'] === 'punch_out' && !empty($punch_stack)) {
                $punch_in_time = array_pop($punch_stack);
                $punch_out_time = strtotime($entry['time']);
                $total_work_seconds += ($punch_out_time - $punch_in_time);
            }
        }
        $punch_in_time = end($punch_stack);
        if ($punch_in_time) {
            $total_work_seconds += strtotime($time) - $punch_in_time;
        }
    }

    // Format times
    $work_formatted = gmdate('H:i:s', $total_work_seconds);
    $lunch_formatted = isset($total_lunch_seconds) ? gmdate('H:i:s', $total_lunch_seconds) : ($existing_entry->total_lunch_time ?? '00:00:00');

    // Update DB
    if ($existing_entry) {
        $update_data = ['log_entries' => json_encode($log_entries)];
        if ($entry_type === 'punch_out') {
            $update_data['total_work_time'] = $work_formatted;
        }
        if ($entry_type === 'lunch_in') {
            $update_data['total_lunch_time'] = $lunch_formatted;
        }
        $wpdb->update($table_name, $update_data, ['id' => $existing_entry->id]);
    } else {
        $insert_data = [
            'user_id' => $user_id,
            'log_entries' => json_encode([$log_entry]),
            'log_date' => $time
        ];
        $wpdb->insert($table_name, $insert_data);
    }

    // File Log
    //$log_dir = plugin_dir_path(__FILE__) . 'logs/';
    // $log_dir = plugin_dir_url(__DIR__) . 'logs/';
    // if (!file_exists($log_dir)) {
    //     mkdir($log_dir, 0755, true);
    // }
    // $log_path = $log_dir . $username . '_log.txt';
    // $log_line = "$entry_type at $time";
    // if ($entry_type === 'punch_out') {
    //     $log_line .= " | Net Work Time: $work_formatted | Lunch Time: $lunch_formatted";
    // }
    // $log_line .= "\n";
    // $existing_file_content = file_exists($log_path) ? file_get_contents($log_path) : '';
    // file_put_contents($log_path, $log_line . $existing_file_content, LOCK_EX);
    $log_dir = plugin_dir_path(__FILE__) . 'logs/';
    if (!file_exists($log_dir)) {
        mkdir($log_dir, 0755, true);
    }
    $log_path = $log_dir . $username . '_log.txt';
    $log_line = "$entry_type at $time";
    if ($entry_type === 'punch_out') {
        $log_line .= " | Net Work Time: $work_formatted | Lunch Time: $lunch_formatted";
    }
    $log_line .= "\n";
    $existing_file_content = file_exists($log_path) ? file_get_contents($log_path) : '';
    file_put_contents($log_path, $log_line . $existing_file_content, LOCK_EX);
    
    wp_send_json_success([
        'message' => ucfirst(str_replace('_', ' ', $entry_type)) . ' recorded.',
        'entry_type' => $entry_type,
        'total_work_time' => $work_formatted,
        'total_lunch_time' => $lunch_formatted,
        'server_time' => $time
    ]);
}


// Get Employee Status
add_action('wp_ajax_eps_get_employee_status', 'eps_get_employee_status');
add_action('wp_ajax_nopriv_eps_get_employee_status', 'eps_get_employee_status');
function eps_get_employee_status() {
    check_ajax_referer('eps_secure_action');
    global $wpdb;
    $table_name = $wpdb->prefix . 'eps_log';

    if (!isset($_SESSION['employee_id'])) {
        wp_send_json_success(['status' => 'not_logged_in']);
    }
    
    $user_id = $_SESSION['employee_id'];
    $today = current_time('Y-m-d', 1);

    $row = $wpdb->get_row(
        $wpdb->prepare("SELECT * FROM $table_name WHERE user_id = %d AND DATE(log_date) = %s", $user_id, $today)
    );

    $status = [];

    if ($row) {
        $entries = json_decode($row->log_entries, true);
        foreach ($entries as $entry) {
            if ($entry['entry_type'] === 'punch_in') {
                $status['punched_in'] = true;
                $status['punched_out'] = false;
                $status['punch_in_time'] = $entry['time']; // ✅ capture punch in time
            }
            if ($entry['entry_type'] === 'punch_out') {
                $status['punched_out'] = true;
            }
            if ($entry['entry_type'] === 'lunch_out') {
                $status['lunch_out'] = true;
            }
            if ($entry['entry_type'] === 'lunch_in') {
                $status['lunch_done'] = true;
            }
        }

        $status['total_work_time'] = $row->total_work_time;
        $status['log_entries'] = $entries; // send all today's entries
        $status['total_lunch_time'] = $row->total_lunch_time;
    }

    wp_send_json_success($status);
}

// Get Server Time
add_action('wp_ajax_get_server_time', 'get_server_time');
add_action('wp_ajax_nopriv_get_server_time', 'get_server_time');
function get_server_time() {
    wp_send_json_success(['server_time' => current_time('mysql')]);
    wp_die();
}






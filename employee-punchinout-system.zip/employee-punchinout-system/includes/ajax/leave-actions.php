<?php
if (!defined('ABSPATH')) exit;
// Apply Leave
function eps_apply_leave() {

    session_start();
    error_log("=== eps_apply_leave triggered ===");
     // Verify nonce
     if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'eps_apply_leave_nonce')) {
        error_log("Nonce verification failed");
        wp_send_json_error(array('message' => 'Nonce verification failed.'));
        wp_die();
    }

   // Check custom employee session
   if (!isset($_SESSION['employee_id'])) {
    error_log("Employee not logged in");
    wp_send_json_error(array('message' => 'You need to log in to apply for leave.'));
    wp_die();
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'eps_leave_applications';
    
    $user_id = $_SESSION['employee_id'];
    $subject = sanitize_text_field($_POST['subject']);
    $from_date = sanitize_text_field($_POST['from_date']);
    $to_date = sanitize_text_field($_POST['to_date']);
    $reason = sanitize_textarea_field($_POST['reason']);
    $leave_type = sanitize_text_field($_POST['leave_type']);
    $half_day_type = isset($_POST['half_day_type']) ? sanitize_text_field($_POST['half_day_type']) : null;
    $half_day_date = isset($_POST['half_day_date']) ? sanitize_text_field($_POST['half_day_date']) : null;
    $short_leave_time = isset($_POST['short_leave_slot']) ? sanitize_text_field($_POST['short_leave_slot']) : null;
    $short_leave_date = isset($_POST['short_leave_date']) ? sanitize_text_field($_POST['short_leave_date']) : null;
    $date_applied = current_time('mysql');
 

    // Log the received data
    error_log("Received data: user_id=$user_id, subject=$subject, from_date=$from_date, to_date=$to_date, reason=$reason, date_applied=$date_applied");


 // Basic validation
 if (empty($subject) || empty($reason) || empty($leave_type)) {
    wp_send_json_error(['message' => 'All required fields must be filled.']);
    wp_die();
}
// Conditional validation
if ($leave_type === 'half_day' && empty($half_day_type)) {
    wp_send_json_error(['message' => 'Please select Half Day Type.']);
    wp_die();
}

if ($leave_type === 'short_leave' && empty($short_leave_time)) {
    wp_send_json_error(['message' => 'Please specify Short Leave Time.']);
    wp_die();
}
if (empty($from_date) && empty($to_date)){
        if($leave_type === 'half_day')
            {
                $from_date = $half_day_date;
            }
        else if ($leave_type === 'short_leave')
        {
            $from_date = $short_leave_date;
         }
}
if ($leave_type === 'full_day' && (empty($from_date) || empty($to_date))) {
    wp_send_json_error(['message' => 'From and To dates are required for full day leave.']);
    wp_die();
}
    $data = array(
        'user_id' => $user_id,
        'subject' => $subject,
        'from_date' => $from_date,
        'to_date' => $to_date,
        'reason' => $reason,
        'leave_type' => $leave_type,
        'half_day_type' => $half_day_type,
        'short_leave_time' => $short_leave_time,
        'date_applied' => $date_applied,
    );

    $already_exists = $wpdb->get_var(
        $wpdb->prepare("SELECT COUNT(*) FROM $table_name WHERE user_id = %d AND subject = %s AND from_date = %s", $user_id, $subject, $from_date)
    );
    
    if ($already_exists > 0) {
        wp_send_json_error(['message' => 'You have already applied for this leave.']);
        wp_die();
    }

$insert = $wpdb->insert($table_name, $data);

if ($insert === false) {
    wp_send_json_error(['message' => 'Failed to submit leave application.']);
} else {
    wp_send_json_success(['message' => 'Leave application submitted successfully.']);
}

wp_die();
}
add_action('wp_ajax_eps_apply_leave', 'eps_apply_leave');
add_action('wp_ajax_nopriv_eps_apply_leave', 'eps_apply_leave');

// Delete Leave
function eps_delete_leave_application() {
    session_start();

    if (!isset($_SESSION['employee_id'])) {
        wp_send_json_error(array('message' => 'You need to log in to delete a leave application.'));
    }

    $leave_id = intval($_POST['leave_id']);
    $user_id = $_SESSION['employee_id'];
    global $wpdb;
    $table_name = $wpdb->prefix . 'eps_leave_applications';
    $emptable_name = $wpdb->prefix . 'employees';
    $emp_data = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT name, email FROM $emptable_name WHERE empid = %d",
            $user_id
        )
    );
    if($emp_data){
        $employee_name = $emp_data->name;
        $employee_email = $emp_data->email;
    }
    $leave_application = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE leave_id = %d AND user_id = %d", $leave_id, $user_id));

    if ($leave_application) {
        $deleted = $wpdb->delete(
            $table_name,
            array('leave_id' => $leave_id, 'user_id' => $user_id),
            array('%d', '%d')
        );

        if ($deleted) {
            $admin_email = get_option('admin_email');
            $email_subject = 'Employee deleted a leave application';
            $message = sprintf(
                "Hello Admin,\n\nAn employee has deleted their leave application.\n\nDetails:\n- Name: %s\n- Email: %s\n- From: %s\n- To: %s\n- Reason: %s\n- Originally applied on: %s\n\nRegards,\nEmployee PunchIn/Out System",
                $employee_name,
                $employee_email,
                $leave_application->from_date,
                $leave_application->to_date,
                $leave_application->reason,
                $leave_application->date_applied
            );
            $headers = array('Content-Type: text/html; charset=UTF-8');
           
            wp_mail($admin_email, $email_subject, $message, $headers);
            wp_send_json_success(array('message' => 'Leave application deleted successfully.'));
        } else {
            wp_send_json_error(array('message' => 'Failed to delete the leave application. Please try again.'));
        }
    } else {
        wp_send_json_error(array('message' => 'Leave application not found or unauthorized.'));
    }

    wp_die();
}
add_action('wp_ajax_eps_delete_leave_application', 'eps_delete_leave_application');
add_action('wp_ajax_nopriv_eps_delete_leave_application', 'eps_delete_leave_application');

//Update Leave
add_action('wp_ajax_eps_update_leave', 'eps_update_leave');
add_action('wp_ajax_nopriv_eps_update_leave', 'eps_update_leave');

function eps_update_leave() {
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'eps_nonce')) {
        wp_send_json_error(['message' => 'Invalid nonce.']);
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'eps_leave_applications';

   // $leave_id = intval($_POST['leave_id']);
    $leave_id = isset($_POST['leave_id']) ? intval($_POST['leave_id']) : 0;
    $update_data = $_POST['update_data'];

    // Get OLD leave data
    $old_leave = $wpdb->get_row(
        $wpdb->prepare("SELECT * FROM $table_name WHERE leave_id = %d", $leave_id),
        ARRAY_A
    );

    if (!$old_leave) {
        wp_send_json_error(['message' => 'Leave not found.']);
    }

    // Prepare the new leave data, clearing unchanged fields
    $new_leave_data = [];

    foreach ($update_data as $key => $value) {
        $new_leave_data[$key] = sanitize_text_field($value);
    }
    if (isset($new_leave_data['date_applied'])) {
        $new_leave_data['date_applied'] = date('Y-m-d H:i:s', strtotime($new_leave_data['date_applied']));
    }
    // Prepare change log
    $change_log = [
        'edited_at' => current_time('mysql'),
        'old_data' => [],
        'new_data' => [],
    ];

    // Compare old and new data to create the log
    foreach ($new_leave_data as $field => $new_value) {
        $old_value = isset($old_leave[$field]) ? $old_leave[$field] : '';
        if ($old_value != $new_value) {
            $change_log['old_data'][$field] = $old_value;
            $change_log['new_data'][$field] = $new_value;
        }
    }

    // Only proceed if there are actual changes
    if (empty($change_log['old_data'])) {
        wp_send_json_success(['message' => 'No changes detected.']);
    }

    // Append to existing leaves_log
    $existing_log = json_decode($old_leave['leaves_log'], true);
    if (!is_array($existing_log)) {
        $existing_log = [];
    }
    $existing_log[] = $change_log;
    $new_leave_data['leaves_log'] = json_encode($existing_log, JSON_UNESCAPED_UNICODE);
   
    
    // Update database
    $updated = $wpdb->update(
        $table_name,
        $new_leave_data,
        ['leave_id' => $leave_id],
        null,
        ['%d']
    );

   // Check if the update was successful
   if ($updated !== false) {
    // Now create or append to the log file
    $employee_name = isset($_SESSION['employee_name']) ? $_SESSION['employee_name'] : 'unknown_employee';
    $log_dir = plugin_dir_path(dirname(__FILE__)) . 'includes/leaveslogs/';
    $log_file_path = $log_dir . $employee_name . '_leaveid_' . $leave_id . '_leavelog.txt';

        // Ensure directory exists
        if (!file_exists($log_dir)) {
            mkdir($log_dir, 0755, true);
        }
    // Append the change log to the file
    $log_content = "Change at: " . current_time('mysql') . "\n" .
                   "Old Data: " . print_r($change_log['old_data'], true) . "\n" .
                   "New Data: " . print_r($change_log['new_data'], true) . "\n\n";

    // Check if the file exists, then append to it, otherwise create it
    file_put_contents($log_file_path, $log_content, FILE_APPEND);

    wp_send_json_success(array_merge($new_leave_data, [
        'message' => 'Leave application updated successfully.',
    ]));
} else {
    wp_send_json_error(['message' => 'Failed to update leave application.']);
}
}


//Filter Leave Applications
add_action('wp_ajax_eps_filter_leave_applications', 'eps_filter_leave_applications');

function eps_filter_leave_applications() {
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'eps_leave_nonce')) {
        wp_send_json_error(['message' => 'Security check failed.']);
    }

    session_start();
    if (!isset($_SESSION['employee_id'])) {
        wp_send_json_error(['message' => 'You must be logged in.']);
    }

    global $wpdb;
    $user_id = $_SESSION['employee_id'];
    $month = sanitize_text_field($_POST['month']);
    $year = sanitize_text_field($_POST['year']);

    $table_name = $wpdb->prefix . 'eps_leave_applications';

    $where = "WHERE user_id = %d";
    $params = [$user_id];

    if ($month) {
        $where .= " AND MONTH(from_date) = %d";
        $params[] = intval($month);
    }

    if ($year) {
        $where .= " AND YEAR(from_date) = %d";
        $params[] = intval($year);
    }

    $query = "SELECT * FROM $table_name $where ORDER BY date_applied DESC";
    $leave_applications = $wpdb->get_results($wpdb->prepare($query, ...$params));

    ob_start();
    if ($leave_applications) {
        include plugin_dir_path(__FILE__) . 'partials/leave-record-table.php'; // You can reuse your table generation in a separate file if needed
    } else {
        echo '<p>No leave records found for the selected period.</p>';
    }
    $table_html = ob_get_clean();

    wp_send_json_success(['table' => $table_html]);
}

//Update Leave Status by Admin/Super Admin Or HR

add_action('wp_ajax_eps_update_leave_status', 'eps_update_leave_status');

function eps_update_leave_status() {
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'eps_update_leave_nonce')) {
        error_log('Nonce failed.');
        wp_send_json_error(['message' => 'Invalid nonce']);
    }
    error_log("POST DATA: " . print_r($_POST, true));

    global $wpdb;

    $leave_id = isset($_POST['leave_id']) ? intval($_POST['leave_id']) : 0;
    $status = isset($_POST['status']) ? sanitize_text_field($_POST['status']) : '';

 
    error_log("Leave ID: $leave_id");
    error_log(" New Status: $status");

    if (!$leave_id || empty($status)) {
        error_log('Missing leave_id or status.');
        wp_send_json_error(['message' => 'Missing data.']);
    }

    // Fetch leave data
    $leave = $wpdb->get_row($wpdb->prepare(
        "SELECT user_id AS empid, leave_type, from_date FROM {$wpdb->prefix}eps_leave_applications WHERE leave_id = %d",
        $leave_id
    ));

    if (!$leave) {
        error_log("Leave not found for ID: $leave_id");
        wp_send_json_error(['message' => 'Leave not found.']);
    }

    // Update leave summary ONLY if approved
    if ($status === 'approved') {
        $empid = $leave->empid;
        $leave_type = $leave->leave_type === 'short' || $leave->leave_type === 'shortleave' ? 'shortleave' : 'fullday';
        $from_date = $leave->from_date;

        eps_update_leave_summary($empid, $leave_type, $from_date);
    }


    $table = $wpdb->prefix . 'eps_leave_applications';

    $result = $wpdb->update(
        $table,
        ['status' => $status],
        ['leave_id' => $leave_id],
        ['%s'],
        ['%d']
    );

    if ($result !== false) {
        if ($result === 0) {
            wp_send_json_success(['message' => 'No change needed. Status already set.']);
        } else {
            wp_send_json_success(['message' => 'Leave status updated.']);
        }
    } else {
        wp_send_json_error(['message' => 'Database update failed.']);
    }
    
    wp_die();
}


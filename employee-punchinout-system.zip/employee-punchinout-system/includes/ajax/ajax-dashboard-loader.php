<?php
function load_dashboard_page_content() {
    // Check nonce for security (you can add a nonce check here if required)
    if (!isset($_POST['security']) || !wp_verify_nonce($_POST['security'], 'dashboard_nonce')) {
        die('Permission denied');
    }

    // Retrieve the page slug from the request
    $page_slug = isset($_POST['page_slug']) ? sanitize_text_field($_POST['page_slug']) : '';
    error_log('AJAX request received for ' . $page_slug);
    if (empty($page_slug)) {
        echo 'No page selected';
        die();
    }

    // Get the page content based on the slug
    $page = get_page_by_path($page_slug);

    if ($page) {
        error_log('Page found: ' . $page->post_title);
        echo apply_filters('the_content', $page->post_content);

    } else {
        error_log('Page not found: ' . $page_slug);
        echo 'Page not found.';
    }
    die();
}
add_action('wp_ajax_load_dashboard_page_content', 'load_dashboard_page_content');
add_action('wp_ajax_nopriv_load_dashboard_page_content', 'load_dashboard_page_content');
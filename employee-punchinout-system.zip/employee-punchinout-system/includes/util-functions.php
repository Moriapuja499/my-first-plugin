<?php
if (!defined('ABSPATH')) {
    exit;
}
function wrap_employee_dashboard_shortcodes($content) {
    if (is_employee_dashboard_subpage() && !is_admin()) {
        // Only wrap if not already wrapped
        if (strpos($content, 'employee-shortcode-wrapper') === false) {
            $content = '<div class="employee-shortcode-wrapper">' . $content . '</div>';
        }
    }
    return $content;
}
add_filter('the_content', 'wrap_employee_dashboard_shortcodes');

function is_employee_dashboard_subpage() {
    // Add all sub-dashboard page slugs here
    
    $dashboard_pages = ['attendance', 'apply-for-leave', 'view-leaves', 'view-log'];
    $current_slug = get_post_field('post_name', get_post());
    return in_array($current_slug, $dashboard_pages);
}


function eps_login_logout_link_shortcode() {
    if (!session_id()) {
        session_start();
    }

    if (isset($_SESSION['employee_id'])) {
        $logout_url = esc_url(add_query_arg('employee_logout', '1', home_url()));
        return '<a href="' . $logout_url . '">Logout</a>';
    } else {
        $login_url = esc_url(home_url('/employee-login')); // Adjust if needed
        return '<a href="' . $login_url . '">Employee Login</a>';
    }
}
add_shortcode('employee_login_logout', 'eps_login_logout_link_shortcode');
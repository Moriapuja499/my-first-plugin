<form method="POST" action="">
    <?php wp_nonce_field('employee_login_action', 'employee_login_nonce'); ?>

    <div class="form-group">
        <label class="login-form-label" for="employee_name">Employee Name <span>*</span></label>
        <input class="login-form-input" type="text" name="employee_name" id="employee_name" required>
    </div>

    <div class="form-group">
        <label class="login-form-label" for="employee_id">Employee ID <span>*</span></label>
        <input class="login-form-input" type="text" name="employee_id" id="employee_id" required>
    </div>

    <div class="form-group password-group">
        <label class="login-form-label" for="password">Password<span> *</span></label>
        <div class="password-wrapper">
            <input class="login-form-input" type="password" name="password" id="password" required>
        </div>
    </div>

    <button type="submit" name="employee_login">Login</button>

    <div class="forgot-password">
        <a href="#">Forgot Password?</a>
    </div>
</form>

<script>
    document.addEventListener('DOMContentLoaded', () => {

        const inputs = document.querySelectorAll('.login-form-input');

        inputs.forEach(input => {
            const label = input.previousElementSibling;

            input.addEventListener('input', () => {
                if (input.value !== '') {
                    label.style.display = 'none';
                } else {
                    label.style.display = 'block';
                }
            });
        });



        // const passwordInput = document.getElementById('password');
        // const togglePassword = document.getElementById('togglePassword');

        // togglePassword.addEventListener('click', () => {
        //     const type = passwordInput.type === 'password' ? 'text' : 'password';
        //     passwordInput.type = type;
        //     togglePassword.textContent = type === 'password' ? '👁️' : '🙈'; 
        // });

    });


</script>

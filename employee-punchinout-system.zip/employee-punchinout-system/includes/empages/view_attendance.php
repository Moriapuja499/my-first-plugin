<?php 
if(!empty($attendance_record)) :
?>
<h2>My Attendance Record</h2>
    <label for="filterYear">Year:</label>
            <select id="filterYear">
                <option value="">All Years</option>
            </select>

            <label for="filterMonth">Month:</label>
            <select id="filterMonth">
                <option value="">All Months</option>
            </select>
            <button id="resetFilters">Reset Filters</button>
    <table id="myAttendanceTable" class="display">
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Punchin</th>
                    <th>Punchout</th>
                    <th>Total Work Time</th>
                    <th>Total Lunch Time</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($attendance_record as $entry): 
                    $first_punch_in = null;
                    $last_punch_out = null;

                    $log_entries = [];
                    if (is_string($entry->log_entries) && !empty($entry->log_entries)) {
                        $decoded = json_decode($entry->log_entries, true);
                        if (json_last_error() === JSON_ERROR_NONE) {
                            $log_entries = $decoded;
                        }
                    }

                    if (is_array($log_entries)) {
                        // Forward loop to get actual first punch-in (oldest entry)
                        foreach ($log_entries as $log) {
                            if ($log['entry_type'] === 'punch_in') {
                                $first_punch_in = $log['time'];
                                break;
                            }
                        }

                        // Reverse loop to get actual last punch-out (latest entry)
                       
                            foreach (array_reverse($log_entries) as $log) {
                            if ($log['entry_type'] === 'punch_out') {
                                $last_punch_out = $log['time'];
                                break;
                            }
                        }
                    }
                ?>


                <tr id="my-attendance-row-<?php echo esc_attr($entry->id); ?>">
                    <!-- <td><input type="text" class="emp-id employee-id" value="<?php //echo esc_html($entry->empid); ?>" readonly>
                    <span class="searchable-text" style="display:none;"><?php //echo esc_html($entry->empid); ?></span></td> -->
                    <td><input type="date" class="log-date" value="<?php echo esc_html($entry->log_date); ?>" readonly>
                    <span class="searchable-date" style="display:none;"><?php echo esc_html($entry->log_date); ?></span></td>
                    <!-- <td><input type="text" class="emp-name employee-name" value="<?php //echo esc_html($entry->name); ?>" readonly>
                    <span class="searchable-text" style="display:none;"><?php //echo esc_html($entry->name); ?></span></td> -->
                    <!-- <td><textarea class="log-entries" readonly><?php //echo esc_html($entry->log_entries); ?></textarea></td> -->
                    <td><input type="text" class="punch-in" value="<?php echo esc_attr($first_punch_in ?? 'N/A'); ?>" readonly></td>
                    <td><input type="text" class="punch-out" value="<?php echo esc_attr($last_punch_out ?? 'N/A'); ?>" readonly></td>
                    <td><input type="text" class="t-work-time" value="<?php echo esc_html($entry->total_work_time); ?>" readonly></td>
                    <td><input type="text" class="t-lunch-time" value="<?php echo esc_html($entry->total_lunch_time); ?>" readonly></td>                              
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php endif; ?>
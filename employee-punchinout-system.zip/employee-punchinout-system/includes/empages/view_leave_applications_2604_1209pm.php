<div class="leave-applications">
    <h1>Your Leave Applications</h1>
    <div id="leaveApplicationList">

    <?php if (!empty($leave_applications)) : ?>

        <div id="leave-applications-table-container">
        <label for="filterYear">Year:</label>
            <select id="filterYear">
                <option value="">All Years</option>
            </select>

            <label for="filterMonth">Month:</label>
            <select id="filterMonth">
                <option value="">All Months</option>
            </select>
            <table id="leaveTable">
                <thead>
                    <tr>
                        <th>Subject</th>
                        <th>From Date</th>
                        <th>To Date</th>
                        <th>Reason</th>
                        <th>Leave Type</th>
                        <th>HalfDay Type</th>
                        <th>ShortLeave Time</th>
                        <th>Date Applied</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($leave_applications as $leave): ?>
                        <tr id="leave-row-<?php echo esc_attr($leave->leave_id); ?>" data-leave-type="<?php echo esc_attr($leave->leave_type); ?>">
                            <td><input type="text" class="subject editable" value="<?php echo esc_html($leave->subject); ?>" readonly></td>
                            <td><input type="date" class="from-date editable" value="<?php echo esc_html($leave->from_date); ?>" readonly></td>
                            <td><input type="date" class="to-date editable" value="<?php echo esc_html($leave->to_date); ?>" readonly></td>
                            <td><textarea class="reason editable" readonly><?php echo esc_html($leave->reason); ?></textarea></td>
                            <td>
                                <select class="leave-type editable" disabled>
                                    <option value="full_day" <?php selected($leave->leave_type, 'full_day'); ?>>FullDay Leave</option>
                                    <option value="half_day" <?php selected($leave->leave_type, 'half_day'); ?>>HalfDay Leave</option>
                                    <option value="short_leave" <?php selected($leave->leave_type, 'short_leave'); ?>>Short Leave</option>
                                </select>
                            </td>
                            <td>
                                <select class="half-day-type editable" disabled>
                                    <option value="first_half" <?php selected($leave->half_day_type, 'first_half'); ?>>First Half</option>
                                    <option value="second_half" <?php selected($leave->half_day_type, 'second_half'); ?>>Second Half</option>
                                </select>
                            </td>
                            <td>
                                <select class="short-leave-time editable" disabled>
                                    <option value="1st_quarter" <?php selected($leave->short_leave_time, '1st_quarter'); ?>>1st Quarter</option>
                                    <option value="2nd_quarter" <?php selected($leave->short_leave_time, '2nd_quarter'); ?>>2nd Quarter</option>
                                    <option value="3rd_quarter" <?php selected($leave->short_leave_time, '3rd_quarter'); ?>>3rd Quarter</option>
                                    <option value="4th_quarter" <?php selected($leave->short_leave_time, '4th_quarter'); ?>>4th Quarter</option>
                                </select>
                            </td>
                            <td><input type="datetime-local" class="date-applied editable" value="<?php echo esc_html($leave->date_applied); ?>" readonly></td>
                            <td><input type="text" class="status" value="<?php echo esc_html($leave->status); ?>" readonly></td>
                            <td>
                                <?php if (in_array($leave->status, ['approved', 'not approved', 'not-approved'])): ?>
                                    <button class="status-leave-btn" data-leave-id="<?php echo esc_attr($leave->leave_id); ?>"><?php echo esc_html($leave->status); ?></button>
                                <?php else: ?>
                                    <button class="edit-leave-btn" data-leave-id="<?php echo esc_attr($leave->leave_id); ?>">Edit</button>
                                <?php endif; ?>
                                <button class="delete-leave" data-id="<?php echo esc_attr($leave->leave_id); ?>">Delete</button>
                                 <!-- Add View Log Button -->
                                 <button class="view-log-btn" data-leave-id="<?php echo esc_attr($leave->leave_id); ?>">LeavesLog</button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        
        </div>
    <?php else: ?>
        <p>You have no leave applications.</p>
    <?php endif; ?>

    </div>
    <div id="leaveApplicationMessage"></div>
</div>
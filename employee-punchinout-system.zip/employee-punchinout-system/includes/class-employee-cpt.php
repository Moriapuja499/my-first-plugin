<?php
class Employee_CPT {
    public static function init() {
        add_action( 'init', [ __CLASS__, 'register_employee_cpt' ] );
    }

    public static function register_employee_cpt() {
        $labels = [
            'name'               => __( 'Employees', 'employee-punchinout-system' ),
            'singular_name'      => __( 'Employee', 'employee-punchinout-system' ),
            'add_new'            => __( 'Add New Employee', 'employee-punchinout-system' ),
            'edit_item'          => __( 'Edit Employee', 'employee-punchinout-system' ),
            'view_item'          => __( 'View Employee', 'employee-punchinout-system' ),
            'all_items'          => __( 'All Employees', 'employee-punchinout-system' ),
        ];

        $args = [
            'labels'             => $labels,
            'public'             => false,
            'show_ui'            => true,
            'capability_type'    => 'employee',
            'map_meta_cap'       => true,
            'supports'           => [ 'title', 'editor', 'custom-fields' ],
            'menu_icon'          => 'dashicons-id',
        ];

        register_post_type( 'employee', $args );
    }

    // public static function create_database_tables() {
    //     global $wpdb;

    //     $table_name = $wpdb->prefix . 'employees';
    //     $charset_collate = $wpdb->get_charset_collate();

    //     $sql = "CREATE TABLE $table_name (
    //         empid VARCHAR(50) NOT NULL PRIMARY KEY,
    //         name varchar(255) NOT NULL,
    //         email varchar(255) NOT NULL,
    //         department varchar(255),
    //         designation varchar(255),
    //         job_type varchar(255),
    //         password varchar(255),
    //         created_at datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
    //     ) $charset_collate;";

    //     require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    //     dbDelta( $sql );
    // }
}

Employee_CPT::init();
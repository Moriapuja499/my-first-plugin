<?php
if (!defined('ABSPATH')) {
    exit;
}

// Create Log Table
function eps_create_log_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'eps_log';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id int(11) NOT NULL AUTO_INCREMENT,
        user_id bigint(20) NOT NULL,
        log_entries longtext NOT NULL,
        total_work_time varchar(255) DEFAULT NULL,
        total_lunch_time varchar(255) DEFAULT NULL,
        log_date date NOT NULL,
        PRIMARY KEY (id),
        UNIQUE KEY user_log_date (user_id, log_date)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

// Create Leave Application Table
function eps_create_leave_application_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'eps_leave_applications';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        leave_id int(11) NOT NULL AUTO_INCREMENT,
        user_id bigint(20) NOT NULL,
        subject varchar(155) NOT NULL,
        from_date date NOT NULL,
        to_date date NOT NULL,
        reason text NOT NULL,
        leave_type text NOT NULL,
        half_day_type text DEFAULT NULL,
        short_leave_time text DEFAULT NULL,
        leaves_log longtext DEFAULT NULL,
        date_applied datetime NOT NULL,
       PRIMARY KEY (leave_id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

function create_eps_management_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'eps_employees_data';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id INT NOT NULL AUTO_INCREMENT,
        emp_id BIGINT NOT NULL,
        personal_info LONGTEXT NOT NULL,
        professional_info LONGTEXT NOT NULL,
        account_access LONGTEXT NOT NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";
    
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql);
}


?>